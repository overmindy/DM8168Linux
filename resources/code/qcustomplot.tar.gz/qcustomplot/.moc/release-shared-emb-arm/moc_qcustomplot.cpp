/****************************************************************************
** Meta object code from reading C++ file 'qcustomplot.h'
**
** Created: Wed Oct 27 01:01:52 2021
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../qcustomplot.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qcustomplot.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_QCP[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
      13,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       4, 0x0,    3,   66,
      19, 0x0,    2,   72,
      29, 0x0,    3,   76,
      40, 0x0,    6,   82,
      51, 0x1,    6,   94,
      63, 0x0,   13,  106,
      82, 0x1,   13,  132,
     102, 0x0,    4,  158,
     115, 0x1,    4,  166,
     129, 0x0,   10,  174,
     141, 0x1,   10,  194,
     154, 0x0,    4,  214,
     172, 0x0,    5,  222,

 // enum data: key, value
     186, uint(QCP::ruDotsPerMeter),
     201, uint(QCP::ruDotsPerCentimeter),
     221, uint(QCP::ruDotsPerInch),
     235, uint(QCP::epNoCosmetic),
     248, uint(QCP::epAllowCosmetic),
     264, uint(QCP::sdNegative),
     275, uint(QCP::sdBoth),
     282, uint(QCP::sdPositive),
     293, uint(QCP::msLeft),
     300, uint(QCP::msRight),
     308, uint(QCP::msTop),
     314, uint(QCP::msBottom),
     323, uint(QCP::msAll),
     329, uint(QCP::msNone),
     293, uint(QCP::msLeft),
     300, uint(QCP::msRight),
     308, uint(QCP::msTop),
     314, uint(QCP::msBottom),
     323, uint(QCP::msAll),
     329, uint(QCP::msNone),
     336, uint(QCP::aeAxes),
     343, uint(QCP::aeGrid),
     350, uint(QCP::aeSubGrid),
     360, uint(QCP::aeLegend),
     369, uint(QCP::aeLegendItems),
     383, uint(QCP::aePlottables),
     396, uint(QCP::aeItems),
     404, uint(QCP::aeScatters),
     415, uint(QCP::aeFills),
     423, uint(QCP::aeZeroLine),
     434, uint(QCP::aeOther),
     442, uint(QCP::aeAll),
     448, uint(QCP::aeNone),
     336, uint(QCP::aeAxes),
     343, uint(QCP::aeGrid),
     350, uint(QCP::aeSubGrid),
     360, uint(QCP::aeLegend),
     369, uint(QCP::aeLegendItems),
     383, uint(QCP::aePlottables),
     396, uint(QCP::aeItems),
     404, uint(QCP::aeScatters),
     415, uint(QCP::aeFills),
     423, uint(QCP::aeZeroLine),
     434, uint(QCP::aeOther),
     442, uint(QCP::aeAll),
     448, uint(QCP::aeNone),
     455, uint(QCP::phNone),
     462, uint(QCP::phFastPolylines),
     478, uint(QCP::phImmediateRefresh),
     497, uint(QCP::phCacheLabels),
     455, uint(QCP::phNone),
     462, uint(QCP::phFastPolylines),
     478, uint(QCP::phImmediateRefresh),
     497, uint(QCP::phCacheLabels),
     511, uint(QCP::iNone),
     517, uint(QCP::iRangeDrag),
     528, uint(QCP::iRangeZoom),
     539, uint(QCP::iMultiSelect),
     552, uint(QCP::iSelectPlottables),
     570, uint(QCP::iSelectAxes),
     582, uint(QCP::iSelectLegend),
     596, uint(QCP::iSelectItems),
     609, uint(QCP::iSelectOther),
     622, uint(QCP::iSelectPlottablesBeyondAxisRect),
     511, uint(QCP::iNone),
     517, uint(QCP::iRangeDrag),
     528, uint(QCP::iRangeZoom),
     539, uint(QCP::iMultiSelect),
     552, uint(QCP::iSelectPlottables),
     570, uint(QCP::iSelectAxes),
     582, uint(QCP::iSelectLegend),
     596, uint(QCP::iSelectItems),
     609, uint(QCP::iSelectOther),
     622, uint(QCP::iSelectPlottablesBeyondAxisRect),
     654, uint(QCP::srmNone),
     662, uint(QCP::srmZoom),
     670, uint(QCP::srmSelect),
     680, uint(QCP::srmCustom),
     690, uint(QCP::stNone),
     697, uint(QCP::stWhole),
     705, uint(QCP::stSingleData),
     718, uint(QCP::stDataRange),
     730, uint(QCP::stMultipleDataRanges),

       0        // eod
};

static const char qt_meta_stringdata_QCP[] = {
    "QCP\0ResolutionUnit\0ExportPen\0SignDomain\0"
    "MarginSide\0MarginSides\0AntialiasedElement\0"
    "AntialiasedElements\0PlottingHint\0"
    "PlottingHints\0Interaction\0Interactions\0"
    "SelectionRectMode\0SelectionType\0"
    "ruDotsPerMeter\0ruDotsPerCentimeter\0"
    "ruDotsPerInch\0epNoCosmetic\0epAllowCosmetic\0"
    "sdNegative\0sdBoth\0sdPositive\0msLeft\0"
    "msRight\0msTop\0msBottom\0msAll\0msNone\0"
    "aeAxes\0aeGrid\0aeSubGrid\0aeLegend\0"
    "aeLegendItems\0aePlottables\0aeItems\0"
    "aeScatters\0aeFills\0aeZeroLine\0aeOther\0"
    "aeAll\0aeNone\0phNone\0phFastPolylines\0"
    "phImmediateRefresh\0phCacheLabels\0iNone\0"
    "iRangeDrag\0iRangeZoom\0iMultiSelect\0"
    "iSelectPlottables\0iSelectAxes\0"
    "iSelectLegend\0iSelectItems\0iSelectOther\0"
    "iSelectPlottablesBeyondAxisRect\0srmNone\0"
    "srmZoom\0srmSelect\0srmCustom\0stNone\0"
    "stWhole\0stSingleData\0stDataRange\0"
    "stMultipleDataRanges\0"
};

const QMetaObject QCP::staticMetaObject = {
    { 0, qt_meta_stringdata_QCP,
      qt_meta_data_QCP, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCP::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION
static const uint qt_meta_data_QCPPainter[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       2,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
      11, 0x0,    4,   22,
      23, 0x1,    4,   30,

 // enum data: key, value
      36, uint(QCPPainter::pmDefault),
      46, uint(QCPPainter::pmVectorized),
      59, uint(QCPPainter::pmNoCaching),
      71, uint(QCPPainter::pmNonCosmetic),
      36, uint(QCPPainter::pmDefault),
      46, uint(QCPPainter::pmVectorized),
      59, uint(QCPPainter::pmNoCaching),
      71, uint(QCPPainter::pmNonCosmetic),

       0        // eod
};

static const char qt_meta_stringdata_QCPPainter[] = {
    "QCPPainter\0PainterMode\0PainterModes\0"
    "pmDefault\0pmVectorized\0pmNoCaching\0"
    "pmNonCosmetic\0"
};

const QMetaObject QCPPainter::staticMetaObject = {
    { &QPainter::staticMetaObject, qt_meta_stringdata_QCPPainter,
      qt_meta_data_QCPPainter, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPPainter::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION
static const uint qt_meta_data_QCPLayer[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       6,   14, // properties
       1,   32, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      22,    9, 0x00095009,
      41,   33, 0x0a095001,
      50,   46, 0x02095001,
      77,   56, 0x00095009,
      91,   86, 0x01095103,
     109,   99, 0x0009510b,

 // enums: name, flags, count, data
      99, 0x0,    2,   36,

 // enum data: key, value
     114, uint(QCPLayer::lmLogical),
     124, uint(QCPLayer::lmBuffered),

       0        // eod
};

static const char qt_meta_stringdata_QCPLayer[] = {
    "QCPLayer\0QCustomPlot*\0parentPlot\0"
    "QString\0name\0int\0index\0QList<QCPLayerable*>\0"
    "children\0bool\0visible\0LayerMode\0mode\0"
    "lmLogical\0lmBuffered\0"
};

const QMetaObject QCPLayer::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QCPLayer,
      qt_meta_data_QCPLayer, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPLayer::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPLayer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPLayer::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayer))
        return static_cast<void*>(const_cast< QCPLayer*>(this));
    return QObject::qt_metacast(_clname);
}

int QCPLayer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCustomPlot**>(_v) = parentPlot(); break;
        case 1: *reinterpret_cast< QString*>(_v) = name(); break;
        case 2: *reinterpret_cast< int*>(_v) = index(); break;
        case 3: *reinterpret_cast< QList<QCPLayerable*>*>(_v) = children(); break;
        case 4: *reinterpret_cast< bool*>(_v) = visible(); break;
        case 5: *reinterpret_cast< LayerMode*>(_v) = mode(); break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 4: setVisible(*reinterpret_cast< bool*>(_v)); break;
        case 5: setMode(*reinterpret_cast< LayerMode*>(_v)); break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 6;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPLayerable[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       5,   24, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      23,   14,   13,   13, 0x05,

 // slots: signature, parameters, type, tag, flags
      58,   52,   47,   13, 0x0a,

 // properties: name, type, flags
      78,   47, 0x01095103,
      99,   86, 0x00095009,
     124,  110, 0x00095009,
      52,  140, 0x0049510b,
     150,   47, 0x01095103,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,

       0        // eod
};

static const char qt_meta_stringdata_QCPLayerable[] = {
    "QCPLayerable\0\0newLayer\0layerChanged(QCPLayer*)\0"
    "bool\0layer\0setLayer(QCPLayer*)\0visible\0"
    "QCustomPlot*\0parentPlot\0QCPLayerable*\0"
    "parentLayerable\0QCPLayer*\0antialiased\0"
};

const QMetaObject QCPLayerable::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QCPLayerable,
      qt_meta_data_QCPLayerable, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPLayerable::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPLayerable::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPLayerable::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayerable))
        return static_cast<void*>(const_cast< QCPLayerable*>(this));
    return QObject::qt_metacast(_clname);
}

int QCPLayerable::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: layerChanged((*reinterpret_cast< QCPLayer*(*)>(_a[1]))); break;
        case 1: { bool _r = setLayer((*reinterpret_cast< QCPLayer*(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        default: ;
        }
        _id -= 2;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = visible(); break;
        case 1: *reinterpret_cast< QCustomPlot**>(_v) = parentPlot(); break;
        case 2: *reinterpret_cast< QCPLayerable**>(_v) = parentLayerable(); break;
        case 3: *reinterpret_cast< QCPLayer**>(_v) = layer(); break;
        case 4: *reinterpret_cast< bool*>(_v) = antialiased(); break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setVisible(*reinterpret_cast< bool*>(_v)); break;
        case 3: setLayer(*reinterpret_cast< QCPLayer**>(_v)); break;
        case 4: setAntialiased(*reinterpret_cast< bool*>(_v)); break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPLayerable::layerChanged(QCPLayer * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
static const uint qt_meta_data_QCPSelectionRect[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: signature, parameters, type, tag, flags
      24,   18,   17,   17, 0x05,
      57,   46,   17,   17, 0x05,
      85,   46,   17,   17, 0x05,
     114,   46,   17,   17, 0x05,

 // slots: signature, parameters, type, tag, flags
     143,   17,   17,   17, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_QCPSelectionRect[] = {
    "QCPSelectionRect\0\0event\0started(QMouseEvent*)\0"
    "rect,event\0changed(QRect,QMouseEvent*)\0"
    "canceled(QRect,QInputEvent*)\0"
    "accepted(QRect,QMouseEvent*)\0cancel()\0"
};

const QMetaObject QCPSelectionRect::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPSelectionRect,
      qt_meta_data_QCPSelectionRect, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPSelectionRect::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPSelectionRect::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPSelectionRect::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPSelectionRect))
        return static_cast<void*>(const_cast< QCPSelectionRect*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPSelectionRect::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: started((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 1: changed((*reinterpret_cast< const QRect(*)>(_a[1])),(*reinterpret_cast< QMouseEvent*(*)>(_a[2]))); break;
        case 2: canceled((*reinterpret_cast< const QRect(*)>(_a[1])),(*reinterpret_cast< QInputEvent*(*)>(_a[2]))); break;
        case 3: accepted((*reinterpret_cast< const QRect(*)>(_a[1])),(*reinterpret_cast< QMouseEvent*(*)>(_a[2]))); break;
        case 4: cancel(); break;
        default: ;
        }
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void QCPSelectionRect::started(QMouseEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPSelectionRect::changed(const QRect & _t1, QMouseEvent * _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPSelectionRect::canceled(const QRect & _t1, QInputEvent * _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void QCPSelectionRect::accepted(const QRect & _t1, QMouseEvent * _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
static const uint qt_meta_data_QCPMarginGroup[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_QCPMarginGroup[] = {
    "QCPMarginGroup\0"
};

const QMetaObject QCPMarginGroup::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QCPMarginGroup,
      qt_meta_data_QCPMarginGroup, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPMarginGroup::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPMarginGroup::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPMarginGroup::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPMarginGroup))
        return static_cast<void*>(const_cast< QCPMarginGroup*>(this));
    return QObject::qt_metacast(_clname);
}

int QCPMarginGroup::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_QCPLayoutElement[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       8,   14, // properties
       2,   38, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      28,   17, 0x00095009,
      41,   35, 0x13095001,
      46,   35, 0x13095103,
      65,   56, 0x0009510b,
      73,   56, 0x0009510b,
      94,   88, 0x15095103,
     106,   88, 0x15095103,
     137,  118, 0x0009510b,

 // enums: name, flags, count, data
     156, 0x0,    3,   46,
     118, 0x0,    2,   52,

 // enum data: key, value
     168, uint(QCPLayoutElement::upPreparation),
     182, uint(QCPLayoutElement::upMargins),
     192, uint(QCPLayoutElement::upLayout),
     201, uint(QCPLayoutElement::scrInnerRect),
     214, uint(QCPLayoutElement::scrOuterRect),

       0        // eod
};

static const char qt_meta_stringdata_QCPLayoutElement[] = {
    "QCPLayoutElement\0QCPLayout*\0layout\0"
    "QRect\0rect\0outerRect\0QMargins\0margins\0"
    "minimumMargins\0QSize\0minimumSize\0"
    "maximumSize\0SizeConstraintRect\0"
    "sizeConstraintRect\0UpdatePhase\0"
    "upPreparation\0upMargins\0upLayout\0"
    "scrInnerRect\0scrOuterRect\0"
};

const QMetaObject QCPLayoutElement::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPLayoutElement,
      qt_meta_data_QCPLayoutElement, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPLayoutElement::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPLayoutElement::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPLayoutElement::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayoutElement))
        return static_cast<void*>(const_cast< QCPLayoutElement*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPLayoutElement::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCPLayout**>(_v) = layout(); break;
        case 1: *reinterpret_cast< QRect*>(_v) = rect(); break;
        case 2: *reinterpret_cast< QRect*>(_v) = outerRect(); break;
        case 3: *reinterpret_cast< QMargins*>(_v) = margins(); break;
        case 4: *reinterpret_cast< QMargins*>(_v) = minimumMargins(); break;
        case 5: *reinterpret_cast< QSize*>(_v) = minimumSize(); break;
        case 6: *reinterpret_cast< QSize*>(_v) = maximumSize(); break;
        case 7: *reinterpret_cast< SizeConstraintRect*>(_v) = sizeConstraintRect(); break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 2: setOuterRect(*reinterpret_cast< QRect*>(_v)); break;
        case 3: setMargins(*reinterpret_cast< QMargins*>(_v)); break;
        case 4: setMinimumMargins(*reinterpret_cast< QMargins*>(_v)); break;
        case 5: setMinimumSize(*reinterpret_cast< QSize*>(_v)); break;
        case 6: setMaximumSize(*reinterpret_cast< QSize*>(_v)); break;
        case 7: setSizeConstraintRect(*reinterpret_cast< SizeConstraintRect*>(_v)); break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 8;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPLayout[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_QCPLayout[] = {
    "QCPLayout\0"
};

const QMetaObject QCPLayout::staticMetaObject = {
    { &QCPLayoutElement::staticMetaObject, qt_meta_stringdata_QCPLayout,
      qt_meta_data_QCPLayout, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPLayout::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPLayout::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPLayout::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayout))
        return static_cast<void*>(const_cast< QCPLayout*>(this));
    return QCPLayoutElement::qt_metacast(_clname);
}

int QCPLayout::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutElement::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_QCPLayoutGrid[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       8,   14, // properties
       1,   38, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      18,   14, 0x02095001,
      27,   14, 0x02095001,
      53,   39, 0x0009510b,
      74,   39, 0x0009510b,
      92,   14, 0x02095103,
     106,   14, 0x02095103,
     127,  117, 0x0009510b,
     137,   14, 0x02095103,

 // enums: name, flags, count, data
     117, 0x0,    2,   42,

 // enum data: key, value
     142, uint(QCPLayoutGrid::foRowsFirst),
     154, uint(QCPLayoutGrid::foColumnsFirst),

       0        // eod
};

static const char qt_meta_stringdata_QCPLayoutGrid[] = {
    "QCPLayoutGrid\0int\0rowCount\0columnCount\0"
    "QList<double>\0columnStretchFactors\0"
    "rowStretchFactors\0columnSpacing\0"
    "rowSpacing\0FillOrder\0fillOrder\0wrap\0"
    "foRowsFirst\0foColumnsFirst\0"
};

const QMetaObject QCPLayoutGrid::staticMetaObject = {
    { &QCPLayout::staticMetaObject, qt_meta_stringdata_QCPLayoutGrid,
      qt_meta_data_QCPLayoutGrid, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPLayoutGrid::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPLayoutGrid::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPLayoutGrid::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayoutGrid))
        return static_cast<void*>(const_cast< QCPLayoutGrid*>(this));
    return QCPLayout::qt_metacast(_clname);
}

int QCPLayoutGrid::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayout::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = rowCount(); break;
        case 1: *reinterpret_cast< int*>(_v) = columnCount(); break;
        case 2: *reinterpret_cast< QList<double>*>(_v) = columnStretchFactors(); break;
        case 3: *reinterpret_cast< QList<double>*>(_v) = rowStretchFactors(); break;
        case 4: *reinterpret_cast< int*>(_v) = columnSpacing(); break;
        case 5: *reinterpret_cast< int*>(_v) = rowSpacing(); break;
        case 6: *reinterpret_cast< FillOrder*>(_v) = fillOrder(); break;
        case 7: *reinterpret_cast< int*>(_v) = wrap(); break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 2: setColumnStretchFactors(*reinterpret_cast< QList<double>*>(_v)); break;
        case 3: setRowStretchFactors(*reinterpret_cast< QList<double>*>(_v)); break;
        case 4: setColumnSpacing(*reinterpret_cast< int*>(_v)); break;
        case 5: setRowSpacing(*reinterpret_cast< int*>(_v)); break;
        case 6: setFillOrder(*reinterpret_cast< FillOrder*>(_v)); break;
        case 7: setWrap(*reinterpret_cast< int*>(_v)); break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 8;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPLayoutInset[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
      15, 0x0,    2,   18,

 // enum data: key, value
      30, uint(QCPLayoutInset::ipFree),
      37, uint(QCPLayoutInset::ipBorderAligned),

       0        // eod
};

static const char qt_meta_stringdata_QCPLayoutInset[] = {
    "QCPLayoutInset\0InsetPlacement\0ipFree\0"
    "ipBorderAligned\0"
};

const QMetaObject QCPLayoutInset::staticMetaObject = {
    { &QCPLayout::staticMetaObject, qt_meta_stringdata_QCPLayoutInset,
      qt_meta_data_QCPLayoutInset, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPLayoutInset::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPLayoutInset::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPLayoutInset::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayoutInset))
        return static_cast<void*>(const_cast< QCPLayoutInset*>(this));
    return QCPLayout::qt_metacast(_clname);
}

int QCPLayoutInset::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayout::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_QCPLineEnding[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
      14, 0x0,   10,   18,

 // enum data: key, value
      26, uint(QCPLineEnding::esNone),
      33, uint(QCPLineEnding::esFlatArrow),
      45, uint(QCPLineEnding::esSpikeArrow),
      58, uint(QCPLineEnding::esLineArrow),
      70, uint(QCPLineEnding::esDisc),
      77, uint(QCPLineEnding::esSquare),
      86, uint(QCPLineEnding::esDiamond),
      96, uint(QCPLineEnding::esBar),
     102, uint(QCPLineEnding::esHalfBar),
     112, uint(QCPLineEnding::esSkewedBar),

       0        // eod
};

static const char qt_meta_stringdata_QCPLineEnding[] = {
    "QCPLineEnding\0EndingStyle\0esNone\0"
    "esFlatArrow\0esSpikeArrow\0esLineArrow\0"
    "esDisc\0esSquare\0esDiamond\0esBar\0"
    "esHalfBar\0esSkewedBar\0"
};

const QMetaObject QCPLineEnding::staticMetaObject = {
    { 0, qt_meta_stringdata_QCPLineEnding,
      qt_meta_data_QCPLineEnding, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPLineEnding::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION
static const uint qt_meta_data_QCPLabelPainterPrivate[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       3,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
      23, 0x0,    3,   26,
      34, 0x0,    2,   32,
      54, 0x0,    8,   36,

 // enum data: key, value
      65, uint(QCPLabelPainterPrivate::amRectangular),
      79, uint(QCPLabelPainterPrivate::amSkewedUpright),
      95, uint(QCPLabelPainterPrivate::amSkewedRotated),
     111, uint(QCPLabelPainterPrivate::artNormal),
     121, uint(QCPLabelPainterPrivate::artTangent),
     132, uint(QCPLabelPainterPrivate::asLeft),
     139, uint(QCPLabelPainterPrivate::asRight),
     147, uint(QCPLabelPainterPrivate::asTop),
     153, uint(QCPLabelPainterPrivate::asBottom),
     162, uint(QCPLabelPainterPrivate::asTopLeft),
     172, uint(QCPLabelPainterPrivate::asTopRight),
     183, uint(QCPLabelPainterPrivate::asBottomRight),
     197, uint(QCPLabelPainterPrivate::asBottomLeft),

       0        // eod
};

static const char qt_meta_stringdata_QCPLabelPainterPrivate[] = {
    "QCPLabelPainterPrivate\0AnchorMode\0"
    "AnchorReferenceType\0AnchorSide\0"
    "amRectangular\0amSkewedUpright\0"
    "amSkewedRotated\0artNormal\0artTangent\0"
    "asLeft\0asRight\0asTop\0asBottom\0asTopLeft\0"
    "asTopRight\0asBottomRight\0asBottomLeft\0"
};

const QMetaObject QCPLabelPainterPrivate::staticMetaObject = {
    { 0, qt_meta_stringdata_QCPLabelPainterPrivate,
      qt_meta_data_QCPLabelPainterPrivate, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPLabelPainterPrivate::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION
static const uint qt_meta_data_QCPAxisTicker[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
      14, 0x0,    2,   18,

 // enum data: key, value
      31, uint(QCPAxisTicker::tssReadability),
      46, uint(QCPAxisTicker::tssMeetTickCount),

       0        // eod
};

static const char qt_meta_stringdata_QCPAxisTicker[] = {
    "QCPAxisTicker\0TickStepStrategy\0"
    "tssReadability\0tssMeetTickCount\0"
};

const QMetaObject QCPAxisTicker::staticMetaObject = {
    { 0, qt_meta_stringdata_QCPAxisTicker,
      qt_meta_data_QCPAxisTicker, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPAxisTicker::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION
static const uint qt_meta_data_QCPAxisTickerTime[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
      18, 0x0,    5,   18,

 // enum data: key, value
      27, uint(QCPAxisTickerTime::tuMilliseconds),
      42, uint(QCPAxisTickerTime::tuSeconds),
      52, uint(QCPAxisTickerTime::tuMinutes),
      62, uint(QCPAxisTickerTime::tuHours),
      70, uint(QCPAxisTickerTime::tuDays),

       0        // eod
};

static const char qt_meta_stringdata_QCPAxisTickerTime[] = {
    "QCPAxisTickerTime\0TimeUnit\0tuMilliseconds\0"
    "tuSeconds\0tuMinutes\0tuHours\0tuDays\0"
};

const QMetaObject QCPAxisTickerTime::staticMetaObject = {
    { &QCPAxisTicker::staticMetaObject, qt_meta_stringdata_QCPAxisTickerTime,
      qt_meta_data_QCPAxisTickerTime, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPAxisTickerTime::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION
static const uint qt_meta_data_QCPAxisTickerFixed[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
      19, 0x0,    3,   18,

 // enum data: key, value
      33, uint(QCPAxisTickerFixed::ssNone),
      40, uint(QCPAxisTickerFixed::ssMultiples),
      52, uint(QCPAxisTickerFixed::ssPowers),

       0        // eod
};

static const char qt_meta_stringdata_QCPAxisTickerFixed[] = {
    "QCPAxisTickerFixed\0ScaleStrategy\0"
    "ssNone\0ssMultiples\0ssPowers\0"
};

const QMetaObject QCPAxisTickerFixed::staticMetaObject = {
    { &QCPAxisTicker::staticMetaObject, qt_meta_stringdata_QCPAxisTickerFixed,
      qt_meta_data_QCPAxisTickerFixed, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPAxisTickerFixed::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION
static const uint qt_meta_data_QCPAxisTickerPi[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
      16, 0x0,    3,   18,

 // enum data: key, value
      30, uint(QCPAxisTickerPi::fsFloatingPoint),
      46, uint(QCPAxisTickerPi::fsAsciiFractions),
      63, uint(QCPAxisTickerPi::fsUnicodeFractions),

       0        // eod
};

static const char qt_meta_stringdata_QCPAxisTickerPi[] = {
    "QCPAxisTickerPi\0FractionStyle\0"
    "fsFloatingPoint\0fsAsciiFractions\0"
    "fsUnicodeFractions\0"
};

const QMetaObject QCPAxisTickerPi::staticMetaObject = {
    { &QCPAxisTicker::staticMetaObject, qt_meta_stringdata_QCPAxisTickerPi,
      qt_meta_data_QCPAxisTickerPi, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPAxisTickerPi::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION
static const uint qt_meta_data_QCPGrid[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       6,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      13,    8, 0x01095103,
      28,    8, 0x01095103,
      47,    8, 0x01095103,
      72,   67, 0x4d095103,
      76,   67, 0x4d095103,
      87,   67, 0x4d095103,

       0        // eod
};

static const char qt_meta_stringdata_QCPGrid[] = {
    "QCPGrid\0bool\0subGridVisible\0"
    "antialiasedSubGrid\0antialiasedZeroLine\0"
    "QPen\0pen\0subGridPen\0zeroLinePen\0"
};

const QMetaObject QCPGrid::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPGrid,
      qt_meta_data_QCPGrid, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPGrid::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPGrid::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPGrid::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPGrid))
        return static_cast<void*>(const_cast< QCPGrid*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPGrid::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = subGridVisible(); break;
        case 1: *reinterpret_cast< bool*>(_v) = antialiasedSubGrid(); break;
        case 2: *reinterpret_cast< bool*>(_v) = antialiasedZeroLine(); break;
        case 3: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 4: *reinterpret_cast< QPen*>(_v) = subGridPen(); break;
        case 5: *reinterpret_cast< QPen*>(_v) = zeroLinePen(); break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setSubGridVisible(*reinterpret_cast< bool*>(_v)); break;
        case 1: setAntialiasedSubGrid(*reinterpret_cast< bool*>(_v)); break;
        case 2: setAntialiasedZeroLine(*reinterpret_cast< bool*>(_v)); break;
        case 3: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 4: setSubGridPen(*reinterpret_cast< QPen*>(_v)); break;
        case 5: setZeroLinePen(*reinterpret_cast< QPen*>(_v)); break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 6;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPAxis[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
      43,   59, // properties
       6,  231, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: signature, parameters, type, tag, flags
      18,    9,    8,    8, 0x05,
      59,   41,    8,    8, 0x05,
     101,   91,    8,    8, 0x05,
     144,  138,    8,    8, 0x05,
     187,  138,    8,    8, 0x05,

 // slots: signature, parameters, type, tag, flags
     236,  231,    8,    8, 0x0a,
     275,  269,    8,    8, 0x0a,
     310,  294,    8,    8, 0x0a,
     369,  355,    8,    8, 0x0a,

 // properties: name, type, flags
     421,  412, 0x00095009,
     443,  430, 0x00095009,
      91,  452, 0x0049510b,
     269,  462, 0x0049510b,
     476,  471, 0x01095103,
     520,  490, 0x0009510b,
     527,  471, 0x01095103,
     533,  471, 0x01095103,
     548,  544, 0x02095103,
     571,  565, 0x40095103,
     592,  585, 0x43095103,
     614,  607, 0x06095103,
     642,  632, 0x0009510b,
     664,  656, 0x0a095103,
     677,  544, 0x02095103,
     709,  693, 0x00095009,
     737,  720, 0x00095009,
     754,  544, 0x02095103,
     767,  544, 0x02095103,
     781,  471, 0x01095103,
     790,  544, 0x02095103,
     806,  544, 0x02095103,
     828,  823, 0x4d095103,
     836,  823, 0x4d095103,
     844,  823, 0x4d095103,
     855,  565, 0x40095103,
     865,  585, 0x43095103,
     876,  656, 0x0a095103,
     882,  544, 0x02095103,
     895,  544, 0x02095103,
     903,  544, 0x02095103,
     355,  910, 0x0049510b,
     294,  910, 0x0049510b,
     926,  565, 0x40095103,
     948,  565, 0x40095103,
     966,  585, 0x43095103,
     989,  585, 0x43095103,
    1008,  823, 0x4d095103,
    1024,  823, 0x4d095103,
    1040,  823, 0x4d095103,
    1073, 1059, 0x0009510b,
    1085, 1059, 0x0009510b,
    1106, 1097, 0x00095009,

 // properties: notify_signal_id
       0,
       0,
       2,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       3,
       4,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,

 // enums: name, flags, count, data
     412, 0x0,    4,  255,
    1111, 0x1,    4,  263,
     632, 0x0,    2,  271,
     452, 0x0,    2,  275,
    1121, 0x0,    4,  279,
     910, 0x1,    4,  287,

 // enum data: key, value
    1136, uint(QCPAxis::atLeft),
    1143, uint(QCPAxis::atRight),
    1151, uint(QCPAxis::atTop),
    1157, uint(QCPAxis::atBottom),
    1136, uint(QCPAxis::atLeft),
    1143, uint(QCPAxis::atRight),
    1151, uint(QCPAxis::atTop),
    1157, uint(QCPAxis::atBottom),
    1166, uint(QCPAxis::lsInside),
    1175, uint(QCPAxis::lsOutside),
    1185, uint(QCPAxis::stLinear),
    1194, uint(QCPAxis::stLogarithmic),
    1208, uint(QCPAxis::spNone),
    1215, uint(QCPAxis::spAxis),
    1222, uint(QCPAxis::spTickLabels),
    1235, uint(QCPAxis::spAxisLabel),
    1208, uint(QCPAxis::spNone),
    1215, uint(QCPAxis::spAxis),
    1222, uint(QCPAxis::spTickLabels),
    1235, uint(QCPAxis::spAxisLabel),

       0        // eod
};

static const char qt_meta_stringdata_QCPAxis[] = {
    "QCPAxis\0\0newRange\0rangeChanged(QCPRange)\0"
    "newRange,oldRange\0rangeChanged(QCPRange,QCPRange)\0"
    "scaleType\0scaleTypeChanged(QCPAxis::ScaleType)\0"
    "parts\0selectionChanged(QCPAxis::SelectableParts)\0"
    "selectableChanged(QCPAxis::SelectableParts)\0"
    "type\0setScaleType(QCPAxis::ScaleType)\0"
    "range\0setRange(QCPRange)\0selectableParts\0"
    "setSelectableParts(QCPAxis::SelectableParts)\0"
    "selectedParts\0setSelectedParts(QCPAxis::SelectableParts)\0"
    "AxisType\0axisType\0QCPAxisRect*\0axisRect\0"
    "ScaleType\0QCPRange\0bool\0rangeReversed\0"
    "QSharedPointer<QCPAxisTicker>\0ticker\0"
    "ticks\0tickLabels\0int\0tickLabelPadding\0"
    "QFont\0tickLabelFont\0QColor\0tickLabelColor\0"
    "double\0tickLabelRotation\0LabelSide\0"
    "tickLabelSide\0QString\0numberFormat\0"
    "numberPrecision\0QVector<double>\0"
    "tickVector\0QVector<QString>\0"
    "tickVectorLabels\0tickLengthIn\0"
    "tickLengthOut\0subTicks\0subTickLengthIn\0"
    "subTickLengthOut\0QPen\0basePen\0tickPen\0"
    "subTickPen\0labelFont\0labelColor\0label\0"
    "labelPadding\0padding\0offset\0SelectableParts\0"
    "selectedTickLabelFont\0selectedLabelFont\0"
    "selectedTickLabelColor\0selectedLabelColor\0"
    "selectedBasePen\0selectedTickPen\0"
    "selectedSubTickPen\0QCPLineEnding\0"
    "lowerEnding\0upperEnding\0QCPGrid*\0grid\0"
    "AxisTypes\0SelectablePart\0atLeft\0atRight\0"
    "atTop\0atBottom\0lsInside\0lsOutside\0"
    "stLinear\0stLogarithmic\0spNone\0spAxis\0"
    "spTickLabels\0spAxisLabel\0"
};

const QMetaObject QCPAxis::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPAxis,
      qt_meta_data_QCPAxis, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPAxis::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPAxis::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPAxis::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPAxis))
        return static_cast<void*>(const_cast< QCPAxis*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPAxis::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: rangeChanged((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 1: rangeChanged((*reinterpret_cast< const QCPRange(*)>(_a[1])),(*reinterpret_cast< const QCPRange(*)>(_a[2]))); break;
        case 2: scaleTypeChanged((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 3: selectionChanged((*reinterpret_cast< const QCPAxis::SelectableParts(*)>(_a[1]))); break;
        case 4: selectableChanged((*reinterpret_cast< const QCPAxis::SelectableParts(*)>(_a[1]))); break;
        case 5: setScaleType((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 6: setRange((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 7: setSelectableParts((*reinterpret_cast< const QCPAxis::SelectableParts(*)>(_a[1]))); break;
        case 8: setSelectedParts((*reinterpret_cast< const QCPAxis::SelectableParts(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 9;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< AxisType*>(_v) = axisType(); break;
        case 1: *reinterpret_cast< QCPAxisRect**>(_v) = axisRect(); break;
        case 2: *reinterpret_cast< ScaleType*>(_v) = scaleType(); break;
        case 3: *reinterpret_cast< QCPRange*>(_v) = range(); break;
        case 4: *reinterpret_cast< bool*>(_v) = rangeReversed(); break;
        case 5: *reinterpret_cast< QSharedPointer<QCPAxisTicker>*>(_v) = ticker(); break;
        case 6: *reinterpret_cast< bool*>(_v) = ticks(); break;
        case 7: *reinterpret_cast< bool*>(_v) = tickLabels(); break;
        case 8: *reinterpret_cast< int*>(_v) = tickLabelPadding(); break;
        case 9: *reinterpret_cast< QFont*>(_v) = tickLabelFont(); break;
        case 10: *reinterpret_cast< QColor*>(_v) = tickLabelColor(); break;
        case 11: *reinterpret_cast< double*>(_v) = tickLabelRotation(); break;
        case 12: *reinterpret_cast< LabelSide*>(_v) = tickLabelSide(); break;
        case 13: *reinterpret_cast< QString*>(_v) = numberFormat(); break;
        case 14: *reinterpret_cast< int*>(_v) = numberPrecision(); break;
        case 15: *reinterpret_cast< QVector<double>*>(_v) = tickVector(); break;
        case 16: *reinterpret_cast< QVector<QString>*>(_v) = tickVectorLabels(); break;
        case 17: *reinterpret_cast< int*>(_v) = tickLengthIn(); break;
        case 18: *reinterpret_cast< int*>(_v) = tickLengthOut(); break;
        case 19: *reinterpret_cast< bool*>(_v) = subTicks(); break;
        case 20: *reinterpret_cast< int*>(_v) = subTickLengthIn(); break;
        case 21: *reinterpret_cast< int*>(_v) = subTickLengthOut(); break;
        case 22: *reinterpret_cast< QPen*>(_v) = basePen(); break;
        case 23: *reinterpret_cast< QPen*>(_v) = tickPen(); break;
        case 24: *reinterpret_cast< QPen*>(_v) = subTickPen(); break;
        case 25: *reinterpret_cast< QFont*>(_v) = labelFont(); break;
        case 26: *reinterpret_cast< QColor*>(_v) = labelColor(); break;
        case 27: *reinterpret_cast< QString*>(_v) = label(); break;
        case 28: *reinterpret_cast< int*>(_v) = labelPadding(); break;
        case 29: *reinterpret_cast< int*>(_v) = padding(); break;
        case 30: *reinterpret_cast< int*>(_v) = offset(); break;
        case 31: *reinterpret_cast<int*>(_v) = QFlag(selectedParts()); break;
        case 32: *reinterpret_cast<int*>(_v) = QFlag(selectableParts()); break;
        case 33: *reinterpret_cast< QFont*>(_v) = selectedTickLabelFont(); break;
        case 34: *reinterpret_cast< QFont*>(_v) = selectedLabelFont(); break;
        case 35: *reinterpret_cast< QColor*>(_v) = selectedTickLabelColor(); break;
        case 36: *reinterpret_cast< QColor*>(_v) = selectedLabelColor(); break;
        case 37: *reinterpret_cast< QPen*>(_v) = selectedBasePen(); break;
        case 38: *reinterpret_cast< QPen*>(_v) = selectedTickPen(); break;
        case 39: *reinterpret_cast< QPen*>(_v) = selectedSubTickPen(); break;
        case 40: *reinterpret_cast< QCPLineEnding*>(_v) = lowerEnding(); break;
        case 41: *reinterpret_cast< QCPLineEnding*>(_v) = upperEnding(); break;
        case 42: *reinterpret_cast< QCPGrid**>(_v) = grid(); break;
        }
        _id -= 43;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 2: setScaleType(*reinterpret_cast< ScaleType*>(_v)); break;
        case 3: setRange(*reinterpret_cast< QCPRange*>(_v)); break;
        case 4: setRangeReversed(*reinterpret_cast< bool*>(_v)); break;
        case 5: setTicker(*reinterpret_cast< QSharedPointer<QCPAxisTicker>*>(_v)); break;
        case 6: setTicks(*reinterpret_cast< bool*>(_v)); break;
        case 7: setTickLabels(*reinterpret_cast< bool*>(_v)); break;
        case 8: setTickLabelPadding(*reinterpret_cast< int*>(_v)); break;
        case 9: setTickLabelFont(*reinterpret_cast< QFont*>(_v)); break;
        case 10: setTickLabelColor(*reinterpret_cast< QColor*>(_v)); break;
        case 11: setTickLabelRotation(*reinterpret_cast< double*>(_v)); break;
        case 12: setTickLabelSide(*reinterpret_cast< LabelSide*>(_v)); break;
        case 13: setNumberFormat(*reinterpret_cast< QString*>(_v)); break;
        case 14: setNumberPrecision(*reinterpret_cast< int*>(_v)); break;
        case 17: setTickLengthIn(*reinterpret_cast< int*>(_v)); break;
        case 18: setTickLengthOut(*reinterpret_cast< int*>(_v)); break;
        case 19: setSubTicks(*reinterpret_cast< bool*>(_v)); break;
        case 20: setSubTickLengthIn(*reinterpret_cast< int*>(_v)); break;
        case 21: setSubTickLengthOut(*reinterpret_cast< int*>(_v)); break;
        case 22: setBasePen(*reinterpret_cast< QPen*>(_v)); break;
        case 23: setTickPen(*reinterpret_cast< QPen*>(_v)); break;
        case 24: setSubTickPen(*reinterpret_cast< QPen*>(_v)); break;
        case 25: setLabelFont(*reinterpret_cast< QFont*>(_v)); break;
        case 26: setLabelColor(*reinterpret_cast< QColor*>(_v)); break;
        case 27: setLabel(*reinterpret_cast< QString*>(_v)); break;
        case 28: setLabelPadding(*reinterpret_cast< int*>(_v)); break;
        case 29: setPadding(*reinterpret_cast< int*>(_v)); break;
        case 30: setOffset(*reinterpret_cast< int*>(_v)); break;
        case 31: setSelectedParts(QFlag(*reinterpret_cast<int*>(_v))); break;
        case 32: setSelectableParts(QFlag(*reinterpret_cast<int*>(_v))); break;
        case 33: setSelectedTickLabelFont(*reinterpret_cast< QFont*>(_v)); break;
        case 34: setSelectedLabelFont(*reinterpret_cast< QFont*>(_v)); break;
        case 35: setSelectedTickLabelColor(*reinterpret_cast< QColor*>(_v)); break;
        case 36: setSelectedLabelColor(*reinterpret_cast< QColor*>(_v)); break;
        case 37: setSelectedBasePen(*reinterpret_cast< QPen*>(_v)); break;
        case 38: setSelectedTickPen(*reinterpret_cast< QPen*>(_v)); break;
        case 39: setSelectedSubTickPen(*reinterpret_cast< QPen*>(_v)); break;
        case 40: setLowerEnding(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        case 41: setUpperEnding(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        }
        _id -= 43;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 43;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 43;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 43;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 43;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 43;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 43;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPAxis::rangeChanged(const QCPRange & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPAxis::rangeChanged(const QCPRange & _t1, const QCPRange & _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPAxis::scaleTypeChanged(QCPAxis::ScaleType _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void QCPAxis::selectionChanged(const QCPAxis::SelectableParts & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void QCPAxis::selectableChanged(const QCPAxis::SelectableParts & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
static const uint qt_meta_data_QCPScatterStyle[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       3,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
      16, 0x0,    6,   26,
      32, 0x1,    6,   38,
      50, 0x0,   18,   50,

 // enum data: key, value
      63, uint(QCPScatterStyle::spNone),
      70, uint(QCPScatterStyle::spPen),
      76, uint(QCPScatterStyle::spBrush),
      84, uint(QCPScatterStyle::spSize),
      91, uint(QCPScatterStyle::spShape),
      99, uint(QCPScatterStyle::spAll),
      63, uint(QCPScatterStyle::spNone),
      70, uint(QCPScatterStyle::spPen),
      76, uint(QCPScatterStyle::spBrush),
      84, uint(QCPScatterStyle::spSize),
      91, uint(QCPScatterStyle::spShape),
      99, uint(QCPScatterStyle::spAll),
     105, uint(QCPScatterStyle::ssNone),
     112, uint(QCPScatterStyle::ssDot),
     118, uint(QCPScatterStyle::ssCross),
     126, uint(QCPScatterStyle::ssPlus),
     133, uint(QCPScatterStyle::ssCircle),
     142, uint(QCPScatterStyle::ssDisc),
     149, uint(QCPScatterStyle::ssSquare),
     158, uint(QCPScatterStyle::ssDiamond),
     168, uint(QCPScatterStyle::ssStar),
     175, uint(QCPScatterStyle::ssTriangle),
     186, uint(QCPScatterStyle::ssTriangleInverted),
     205, uint(QCPScatterStyle::ssCrossSquare),
     219, uint(QCPScatterStyle::ssPlusSquare),
     232, uint(QCPScatterStyle::ssCrossCircle),
     246, uint(QCPScatterStyle::ssPlusCircle),
     259, uint(QCPScatterStyle::ssPeace),
     267, uint(QCPScatterStyle::ssPixmap),
     276, uint(QCPScatterStyle::ssCustom),

       0        // eod
};

static const char qt_meta_stringdata_QCPScatterStyle[] = {
    "QCPScatterStyle\0ScatterProperty\0"
    "ScatterProperties\0ScatterShape\0spNone\0"
    "spPen\0spBrush\0spSize\0spShape\0spAll\0"
    "ssNone\0ssDot\0ssCross\0ssPlus\0ssCircle\0"
    "ssDisc\0ssSquare\0ssDiamond\0ssStar\0"
    "ssTriangle\0ssTriangleInverted\0"
    "ssCrossSquare\0ssPlusSquare\0ssCrossCircle\0"
    "ssPlusCircle\0ssPeace\0ssPixmap\0ssCustom\0"
};

const QMetaObject QCPScatterStyle::staticMetaObject = {
    { 0, qt_meta_stringdata_QCPScatterStyle,
      qt_meta_data_QCPScatterStyle, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPScatterStyle::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION
static const uint qt_meta_data_QCPSelectionDecorator[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_QCPSelectionDecorator[] = {
    "QCPSelectionDecorator\0"
};

const QMetaObject QCPSelectionDecorator::staticMetaObject = {
    { 0, qt_meta_stringdata_QCPSelectionDecorator,
      qt_meta_data_QCPSelectionDecorator, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPSelectionDecorator::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION
static const uint qt_meta_data_QCPAbstractPlottable[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
      10,   39, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: signature, parameters, type, tag, flags
      31,   22,   21,   21, 0x05,
      64,   54,   21,   21, 0x05,
     110,   99,   21,   21, 0x05,

 // slots: signature, parameters, type, tag, flags
     148,   99,   21,   21, 0x0a,
     182,   54,   21,   21, 0x0a,

 // properties: name, type, flags
     221,  213, 0x0a095103,
     231,  226, 0x01095103,
     247,  226, 0x01095103,
     272,  267, 0x4d095103,
     283,  276, 0x42095103,
     298,  289, 0x0009510b,
     306,  289, 0x0009510b,
      99,  316, 0x0049510b,
      54,  335, 0x0049510b,
     375,  352, 0x0009510b,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       2,
       0,
       0,

       0        // eod
};

static const char qt_meta_stringdata_QCPAbstractPlottable[] = {
    "QCPAbstractPlottable\0\0selected\0"
    "selectionChanged(bool)\0selection\0"
    "selectionChanged(QCPDataSelection)\0"
    "selectable\0selectableChanged(QCP::SelectionType)\0"
    "setSelectable(QCP::SelectionType)\0"
    "setSelection(QCPDataSelection)\0QString\0"
    "name\0bool\0antialiasedFill\0antialiasedScatters\0"
    "QPen\0pen\0QBrush\0brush\0QCPAxis*\0keyAxis\0"
    "valueAxis\0QCP::SelectionType\0"
    "QCPDataSelection\0QCPSelectionDecorator*\0"
    "selectionDecorator\0"
};

const QMetaObject QCPAbstractPlottable::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPAbstractPlottable,
      qt_meta_data_QCPAbstractPlottable, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPAbstractPlottable::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPAbstractPlottable::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPAbstractPlottable::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPAbstractPlottable))
        return static_cast<void*>(const_cast< QCPAbstractPlottable*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPAbstractPlottable::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: selectionChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: selectionChanged((*reinterpret_cast< const QCPDataSelection(*)>(_a[1]))); break;
        case 2: selectableChanged((*reinterpret_cast< QCP::SelectionType(*)>(_a[1]))); break;
        case 3: setSelectable((*reinterpret_cast< QCP::SelectionType(*)>(_a[1]))); break;
        case 4: setSelection((*reinterpret_cast< QCPDataSelection(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 5;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = name(); break;
        case 1: *reinterpret_cast< bool*>(_v) = antialiasedFill(); break;
        case 2: *reinterpret_cast< bool*>(_v) = antialiasedScatters(); break;
        case 3: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 4: *reinterpret_cast< QBrush*>(_v) = brush(); break;
        case 5: *reinterpret_cast< QCPAxis**>(_v) = keyAxis(); break;
        case 6: *reinterpret_cast< QCPAxis**>(_v) = valueAxis(); break;
        case 7: *reinterpret_cast< QCP::SelectionType*>(_v) = selectable(); break;
        case 8: *reinterpret_cast< QCPDataSelection*>(_v) = selection(); break;
        case 9: *reinterpret_cast< QCPSelectionDecorator**>(_v) = selectionDecorator(); break;
        }
        _id -= 10;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setName(*reinterpret_cast< QString*>(_v)); break;
        case 1: setAntialiasedFill(*reinterpret_cast< bool*>(_v)); break;
        case 2: setAntialiasedScatters(*reinterpret_cast< bool*>(_v)); break;
        case 3: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 4: setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 5: setKeyAxis(*reinterpret_cast< QCPAxis**>(_v)); break;
        case 6: setValueAxis(*reinterpret_cast< QCPAxis**>(_v)); break;
        case 7: setSelectable(*reinterpret_cast< QCP::SelectionType*>(_v)); break;
        case 8: setSelection(*reinterpret_cast< QCPDataSelection*>(_v)); break;
        case 9: setSelectionDecorator(*reinterpret_cast< QCPSelectionDecorator**>(_v)); break;
        }
        _id -= 10;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 10;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPAbstractPlottable::selectionChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPAbstractPlottable::selectionChanged(const QCPDataSelection & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPAbstractPlottable::selectableChanged(QCP::SelectionType _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
static const uint qt_meta_data_QCPItemAnchor[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_QCPItemAnchor[] = {
    "QCPItemAnchor\0"
};

const QMetaObject QCPItemAnchor::staticMetaObject = {
    { 0, qt_meta_stringdata_QCPItemAnchor,
      qt_meta_data_QCPItemAnchor, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPItemAnchor::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION
static const uint qt_meta_data_QCPItemPosition[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
      16, 0x0,    4,   18,

 // enum data: key, value
      29, uint(QCPItemPosition::ptAbsolute),
      40, uint(QCPItemPosition::ptViewportRatio),
      56, uint(QCPItemPosition::ptAxisRectRatio),
      72, uint(QCPItemPosition::ptPlotCoords),

       0        // eod
};

static const char qt_meta_stringdata_QCPItemPosition[] = {
    "QCPItemPosition\0PositionType\0ptAbsolute\0"
    "ptViewportRatio\0ptAxisRectRatio\0"
    "ptPlotCoords\0"
};

const QMetaObject QCPItemPosition::staticMetaObject = {
    { &QCPItemAnchor::staticMetaObject, qt_meta_stringdata_QCPItemPosition,
      qt_meta_data_QCPItemPosition, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPItemPosition::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION
static const uint qt_meta_data_QCPAbstractItem[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       4,   34, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: signature, parameters, type, tag, flags
      26,   17,   16,   16, 0x05,
      60,   49,   16,   16, 0x05,

 // slots: signature, parameters, type, tag, flags
      84,   49,   16,   16, 0x0a,
     104,   17,   16,   16, 0x0a,

 // properties: name, type, flags
     127,  122, 0x01095103,
     155,  142, 0x0009510b,
      49,  122, 0x01495103,
      17,  122, 0x01495103,

 // properties: notify_signal_id
       0,
       0,
       1,
       0,

       0        // eod
};

static const char qt_meta_stringdata_QCPAbstractItem[] = {
    "QCPAbstractItem\0\0selected\0"
    "selectionChanged(bool)\0selectable\0"
    "selectableChanged(bool)\0setSelectable(bool)\0"
    "setSelected(bool)\0bool\0clipToAxisRect\0"
    "QCPAxisRect*\0clipAxisRect\0"
};

const QMetaObject QCPAbstractItem::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPAbstractItem,
      qt_meta_data_QCPAbstractItem, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPAbstractItem::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPAbstractItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPAbstractItem::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPAbstractItem))
        return static_cast<void*>(const_cast< QCPAbstractItem*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPAbstractItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: selectionChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: selectableChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: setSelectable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: setSelected((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 4;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = clipToAxisRect(); break;
        case 1: *reinterpret_cast< QCPAxisRect**>(_v) = clipAxisRect(); break;
        case 2: *reinterpret_cast< bool*>(_v) = selectable(); break;
        case 3: *reinterpret_cast< bool*>(_v) = selected(); break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setClipToAxisRect(*reinterpret_cast< bool*>(_v)); break;
        case 1: setClipAxisRect(*reinterpret_cast< QCPAxisRect**>(_v)); break;
        case 2: setSelectable(*reinterpret_cast< bool*>(_v)); break;
        case 3: setSelected(*reinterpret_cast< bool*>(_v)); break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPAbstractItem::selectionChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPAbstractItem::selectableChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
static const uint qt_meta_data_QCustomPlot[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
      25,   14, // methods
      10,  139, // properties
       2,  169, // enums/sets
       0,    0, // constructors
       0,       // flags
      17,       // signalCount

 // signals: signature, parameters, type, tag, flags
      19,   13,   12,   12, 0x05,
      50,   13,   12,   12, 0x05,
      75,   13,   12,   12, 0x05,
      99,   13,   12,   12, 0x05,
     126,   13,   12,   12, 0x05,
     177,  151,   12,   12, 0x05,
     232,  151,   12,   12, 0x05,
     304,  293,   12,   12, 0x05,
     345,  293,   12,   12, 0x05,
     408,  392,   12,   12, 0x05,
     465,  392,   12,   12, 0x05,
     546,  528,   12,   12, 0x05,
     606,  528,   12,   12, 0x05,
     672,   12,   12,   12, 0x05,
     697,   12,   12,   12, 0x05,
     712,   12,   12,   12, 0x05,
     726,   12,   12,   12, 0x05,

 // slots: signature, parameters, type, tag, flags
     762,  740,   12,   12, 0x0a,
     780,   12,   12,   12, 0x2a,
     794,   12,   12,   12, 0x0a,
     824,  808,   12,   12, 0x0a,
     861,   12,   12,   12, 0x2a,
     881,  870,   12,   12, 0x09,
     922,  870,   12,   12, 0x09,
     958,   13,   12,   12, 0x09,

 // properties: name, type, flags
    1000,  994, 0x13095103,
    1017, 1009, 0x41095103,
    1033, 1028, 0x01095103,
    1070, 1050, 0x0009510b,
    1106, 1091, 0x00095009,
    1117, 1028, 0x01095103,
    1146, 1142, 0x02095103,
    1165, 1028, 0x01095103,
    1207, 1186, 0x0009510b,
    1227, 1028, 0x01095103,

 // enums: name, flags, count, data
    1234, 0x0,    2,  177,
    1250, 0x0,    4,  181,

 // enum data: key, value
    1266, uint(QCustomPlot::limBelow),
    1275, uint(QCustomPlot::limAbove),
    1284, uint(QCustomPlot::rpImmediateRefresh),
    1303, uint(QCustomPlot::rpQueuedRefresh),
    1319, uint(QCustomPlot::rpRefreshHint),
    1333, uint(QCustomPlot::rpQueuedReplot),

       0        // eod
};

static const char qt_meta_stringdata_QCustomPlot[] = {
    "QCustomPlot\0\0event\0mouseDoubleClick(QMouseEvent*)\0"
    "mousePress(QMouseEvent*)\0"
    "mouseMove(QMouseEvent*)\0"
    "mouseRelease(QMouseEvent*)\0"
    "mouseWheel(QWheelEvent*)\0"
    "plottable,dataIndex,event\0"
    "plottableClick(QCPAbstractPlottable*,int,QMouseEvent*)\0"
    "plottableDoubleClick(QCPAbstractPlottable*,int,QMouseEvent*)\0"
    "item,event\0itemClick(QCPAbstractItem*,QMouseEvent*)\0"
    "itemDoubleClick(QCPAbstractItem*,QMouseEvent*)\0"
    "axis,part,event\0"
    "axisClick(QCPAxis*,QCPAxis::SelectablePart,QMouseEvent*)\0"
    "axisDoubleClick(QCPAxis*,QCPAxis::SelectablePart,QMouseEvent*)\0"
    "legend,item,event\0"
    "legendClick(QCPLegend*,QCPAbstractLegendItem*,QMouseEvent*)\0"
    "legendDoubleClick(QCPLegend*,QCPAbstractLegendItem*,QMouseEvent*)\0"
    "selectionChangedByUser()\0beforeReplot()\0"
    "afterLayout()\0afterReplot()\0"
    "onlyVisiblePlottables\0rescaleAxes(bool)\0"
    "rescaleAxes()\0deselectAll()\0refreshPriority\0"
    "replot(QCustomPlot::RefreshPriority)\0"
    "replot()\0rect,event\0"
    "processRectSelection(QRect,QMouseEvent*)\0"
    "processRectZoom(QRect,QMouseEvent*)\0"
    "processPointSelection(QMouseEvent*)\0"
    "QRect\0viewport\0QPixmap\0background\0"
    "bool\0backgroundScaled\0Qt::AspectRatioMode\0"
    "backgroundScaledMode\0QCPLayoutGrid*\0"
    "plotLayout\0autoAddPlottableToLegend\0"
    "int\0selectionTolerance\0noAntialiasingOnDrag\0"
    "Qt::KeyboardModifier\0multiSelectModifier\0"
    "openGl\0LayerInsertMode\0RefreshPriority\0"
    "limBelow\0limAbove\0rpImmediateRefresh\0"
    "rpQueuedRefresh\0rpRefreshHint\0"
    "rpQueuedReplot\0"
};

const QMetaObject QCustomPlot::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_QCustomPlot,
      qt_meta_data_QCustomPlot, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCustomPlot::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCustomPlot::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCustomPlot::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCustomPlot))
        return static_cast<void*>(const_cast< QCustomPlot*>(this));
    return QWidget::qt_metacast(_clname);
}

int QCustomPlot::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: mouseDoubleClick((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 1: mousePress((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 2: mouseMove((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 3: mouseRelease((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 4: mouseWheel((*reinterpret_cast< QWheelEvent*(*)>(_a[1]))); break;
        case 5: plottableClick((*reinterpret_cast< QCPAbstractPlottable*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 6: plottableDoubleClick((*reinterpret_cast< QCPAbstractPlottable*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 7: itemClick((*reinterpret_cast< QCPAbstractItem*(*)>(_a[1])),(*reinterpret_cast< QMouseEvent*(*)>(_a[2]))); break;
        case 8: itemDoubleClick((*reinterpret_cast< QCPAbstractItem*(*)>(_a[1])),(*reinterpret_cast< QMouseEvent*(*)>(_a[2]))); break;
        case 9: axisClick((*reinterpret_cast< QCPAxis*(*)>(_a[1])),(*reinterpret_cast< QCPAxis::SelectablePart(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 10: axisDoubleClick((*reinterpret_cast< QCPAxis*(*)>(_a[1])),(*reinterpret_cast< QCPAxis::SelectablePart(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 11: legendClick((*reinterpret_cast< QCPLegend*(*)>(_a[1])),(*reinterpret_cast< QCPAbstractLegendItem*(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 12: legendDoubleClick((*reinterpret_cast< QCPLegend*(*)>(_a[1])),(*reinterpret_cast< QCPAbstractLegendItem*(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 13: selectionChangedByUser(); break;
        case 14: beforeReplot(); break;
        case 15: afterLayout(); break;
        case 16: afterReplot(); break;
        case 17: rescaleAxes((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 18: rescaleAxes(); break;
        case 19: deselectAll(); break;
        case 20: replot((*reinterpret_cast< QCustomPlot::RefreshPriority(*)>(_a[1]))); break;
        case 21: replot(); break;
        case 22: processRectSelection((*reinterpret_cast< QRect(*)>(_a[1])),(*reinterpret_cast< QMouseEvent*(*)>(_a[2]))); break;
        case 23: processRectZoom((*reinterpret_cast< QRect(*)>(_a[1])),(*reinterpret_cast< QMouseEvent*(*)>(_a[2]))); break;
        case 24: processPointSelection((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 25;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QRect*>(_v) = viewport(); break;
        case 1: *reinterpret_cast< QPixmap*>(_v) = background(); break;
        case 2: *reinterpret_cast< bool*>(_v) = backgroundScaled(); break;
        case 3: *reinterpret_cast< Qt::AspectRatioMode*>(_v) = backgroundScaledMode(); break;
        case 4: *reinterpret_cast< QCPLayoutGrid**>(_v) = plotLayout(); break;
        case 5: *reinterpret_cast< bool*>(_v) = autoAddPlottableToLegend(); break;
        case 6: *reinterpret_cast< int*>(_v) = selectionTolerance(); break;
        case 7: *reinterpret_cast< bool*>(_v) = noAntialiasingOnDrag(); break;
        case 8: *reinterpret_cast< Qt::KeyboardModifier*>(_v) = multiSelectModifier(); break;
        case 9: *reinterpret_cast< bool*>(_v) = openGl(); break;
        }
        _id -= 10;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setViewport(*reinterpret_cast< QRect*>(_v)); break;
        case 1: setBackground(*reinterpret_cast< QPixmap*>(_v)); break;
        case 2: setBackgroundScaled(*reinterpret_cast< bool*>(_v)); break;
        case 3: setBackgroundScaledMode(*reinterpret_cast< Qt::AspectRatioMode*>(_v)); break;
        case 5: setAutoAddPlottableToLegend(*reinterpret_cast< bool*>(_v)); break;
        case 6: setSelectionTolerance(*reinterpret_cast< int*>(_v)); break;
        case 7: setNoAntialiasingOnDrag(*reinterpret_cast< bool*>(_v)); break;
        case 8: setMultiSelectModifier(*reinterpret_cast< Qt::KeyboardModifier*>(_v)); break;
        case 9: setOpenGl(*reinterpret_cast< bool*>(_v)); break;
        }
        _id -= 10;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 10;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCustomPlot::mouseDoubleClick(QMouseEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCustomPlot::mousePress(QMouseEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCustomPlot::mouseMove(QMouseEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void QCustomPlot::mouseRelease(QMouseEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void QCustomPlot::mouseWheel(QWheelEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void QCustomPlot::plottableClick(QCPAbstractPlottable * _t1, int _t2, QMouseEvent * _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void QCustomPlot::plottableDoubleClick(QCPAbstractPlottable * _t1, int _t2, QMouseEvent * _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void QCustomPlot::itemClick(QCPAbstractItem * _t1, QMouseEvent * _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void QCustomPlot::itemDoubleClick(QCPAbstractItem * _t1, QMouseEvent * _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void QCustomPlot::axisClick(QCPAxis * _t1, QCPAxis::SelectablePart _t2, QMouseEvent * _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void QCustomPlot::axisDoubleClick(QCPAxis * _t1, QCPAxis::SelectablePart _t2, QMouseEvent * _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void QCustomPlot::legendClick(QCPLegend * _t1, QCPAbstractLegendItem * _t2, QMouseEvent * _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void QCustomPlot::legendDoubleClick(QCPLegend * _t1, QCPAbstractLegendItem * _t2, QMouseEvent * _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void QCustomPlot::selectionChangedByUser()
{
    QMetaObject::activate(this, &staticMetaObject, 13, 0);
}

// SIGNAL 14
void QCustomPlot::beforeReplot()
{
    QMetaObject::activate(this, &staticMetaObject, 14, 0);
}

// SIGNAL 15
void QCustomPlot::afterLayout()
{
    QMetaObject::activate(this, &staticMetaObject, 15, 0);
}

// SIGNAL 16
void QCustomPlot::afterReplot()
{
    QMetaObject::activate(this, &staticMetaObject, 16, 0);
}
static const uint qt_meta_data_QCPColorGradient[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       3,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
      17, 0x0,    2,   26,
      36, 0x0,    5,   30,
      48, 0x0,   12,   40,

 // enum data: key, value
      63, uint(QCPColorGradient::ciRGB),
      69, uint(QCPColorGradient::ciHSV),
      75, uint(QCPColorGradient::nhNone),
      82, uint(QCPColorGradient::nhLowestColor),
      96, uint(QCPColorGradient::nhHighestColor),
     111, uint(QCPColorGradient::nhTransparent),
     125, uint(QCPColorGradient::nhNanColor),
     136, uint(QCPColorGradient::gpGrayscale),
     148, uint(QCPColorGradient::gpHot),
     154, uint(QCPColorGradient::gpCold),
     161, uint(QCPColorGradient::gpNight),
     169, uint(QCPColorGradient::gpCandy),
     177, uint(QCPColorGradient::gpGeography),
     189, uint(QCPColorGradient::gpIon),
     195, uint(QCPColorGradient::gpThermal),
     205, uint(QCPColorGradient::gpPolar),
     213, uint(QCPColorGradient::gpSpectrum),
     224, uint(QCPColorGradient::gpJet),
     230, uint(QCPColorGradient::gpHues),

       0        // eod
};

static const char qt_meta_stringdata_QCPColorGradient[] = {
    "QCPColorGradient\0ColorInterpolation\0"
    "NanHandling\0GradientPreset\0ciRGB\0ciHSV\0"
    "nhNone\0nhLowestColor\0nhHighestColor\0"
    "nhTransparent\0nhNanColor\0gpGrayscale\0"
    "gpHot\0gpCold\0gpNight\0gpCandy\0gpGeography\0"
    "gpIon\0gpThermal\0gpPolar\0gpSpectrum\0"
    "gpJet\0gpHues\0"
};

const QMetaObject QCPColorGradient::staticMetaObject = {
    { 0, qt_meta_stringdata_QCPColorGradient,
      qt_meta_data_QCPColorGradient, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPColorGradient::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION
static const uint qt_meta_data_QCPSelectionDecoratorBracket[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
      29, 0x0,    5,   18,

 // enum data: key, value
      42, uint(QCPSelectionDecoratorBracket::bsSquareBracket),
      58, uint(QCPSelectionDecoratorBracket::bsHalfEllipse),
      72, uint(QCPSelectionDecoratorBracket::bsEllipse),
      82, uint(QCPSelectionDecoratorBracket::bsPlus),
      89, uint(QCPSelectionDecoratorBracket::bsUserStyle),

       0        // eod
};

static const char qt_meta_stringdata_QCPSelectionDecoratorBracket[] = {
    "QCPSelectionDecoratorBracket\0BracketStyle\0"
    "bsSquareBracket\0bsHalfEllipse\0bsEllipse\0"
    "bsPlus\0bsUserStyle\0"
};

const QMetaObject QCPSelectionDecoratorBracket::staticMetaObject = {
    { &QCPSelectionDecorator::staticMetaObject, qt_meta_stringdata_QCPSelectionDecoratorBracket,
      qt_meta_data_QCPSelectionDecoratorBracket, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPSelectionDecoratorBracket::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION
static const uint qt_meta_data_QCPAxisRect[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       5,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      20,   12, 0x41095103,
      36,   31, 0x01095103,
      73,   53, 0x0009510b,
     111,   94, 0x0009510b,
     121,   94, 0x0009510b,

       0        // eod
};

static const char qt_meta_stringdata_QCPAxisRect[] = {
    "QCPAxisRect\0QPixmap\0background\0bool\0"
    "backgroundScaled\0Qt::AspectRatioMode\0"
    "backgroundScaledMode\0Qt::Orientations\0"
    "rangeDrag\0rangeZoom\0"
};

const QMetaObject QCPAxisRect::staticMetaObject = {
    { &QCPLayoutElement::staticMetaObject, qt_meta_stringdata_QCPAxisRect,
      qt_meta_data_QCPAxisRect, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPAxisRect::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPAxisRect::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPAxisRect::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPAxisRect))
        return static_cast<void*>(const_cast< QCPAxisRect*>(this));
    return QCPLayoutElement::qt_metacast(_clname);
}

int QCPAxisRect::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutElement::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPixmap*>(_v) = background(); break;
        case 1: *reinterpret_cast< bool*>(_v) = backgroundScaled(); break;
        case 2: *reinterpret_cast< Qt::AspectRatioMode*>(_v) = backgroundScaledMode(); break;
        case 3: *reinterpret_cast< Qt::Orientations*>(_v) = rangeDrag(); break;
        case 4: *reinterpret_cast< Qt::Orientations*>(_v) = rangeZoom(); break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setBackground(*reinterpret_cast< QPixmap*>(_v)); break;
        case 1: setBackgroundScaled(*reinterpret_cast< bool*>(_v)); break;
        case 2: setBackgroundScaledMode(*reinterpret_cast< Qt::AspectRatioMode*>(_v)); break;
        case 3: setRangeDrag(*reinterpret_cast< Qt::Orientations*>(_v)); break;
        case 4: setRangeZoom(*reinterpret_cast< Qt::Orientations*>(_v)); break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPAbstractLegendItem[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       7,   34, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: signature, parameters, type, tag, flags
      32,   23,   22,   22, 0x05,
      66,   55,   22,   22, 0x05,

 // slots: signature, parameters, type, tag, flags
      90,   55,   22,   22, 0x0a,
     110,   23,   22,   22, 0x0a,

 // properties: name, type, flags
     139,  128, 0x00095009,
     158,  152, 0x40095103,
     170,  163, 0x43095103,
     180,  152, 0x40095103,
     193,  163, 0x43095103,
      55,  211, 0x01495103,
      23,  211, 0x01495103,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,
       0,
       1,

       0        // eod
};

static const char qt_meta_stringdata_QCPAbstractLegendItem[] = {
    "QCPAbstractLegendItem\0\0selected\0"
    "selectionChanged(bool)\0selectable\0"
    "selectableChanged(bool)\0setSelectable(bool)\0"
    "setSelected(bool)\0QCPLegend*\0parentLegend\0"
    "QFont\0font\0QColor\0textColor\0selectedFont\0"
    "selectedTextColor\0bool\0"
};

const QMetaObject QCPAbstractLegendItem::staticMetaObject = {
    { &QCPLayoutElement::staticMetaObject, qt_meta_stringdata_QCPAbstractLegendItem,
      qt_meta_data_QCPAbstractLegendItem, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPAbstractLegendItem::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPAbstractLegendItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPAbstractLegendItem::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPAbstractLegendItem))
        return static_cast<void*>(const_cast< QCPAbstractLegendItem*>(this));
    return QCPLayoutElement::qt_metacast(_clname);
}

int QCPAbstractLegendItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutElement::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: selectionChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: selectableChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: setSelectable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: setSelected((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 4;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCPLegend**>(_v) = parentLegend(); break;
        case 1: *reinterpret_cast< QFont*>(_v) = font(); break;
        case 2: *reinterpret_cast< QColor*>(_v) = textColor(); break;
        case 3: *reinterpret_cast< QFont*>(_v) = selectedFont(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = selectedTextColor(); break;
        case 5: *reinterpret_cast< bool*>(_v) = selectable(); break;
        case 6: *reinterpret_cast< bool*>(_v) = selected(); break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 1: setFont(*reinterpret_cast< QFont*>(_v)); break;
        case 2: setTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 3: setSelectedFont(*reinterpret_cast< QFont*>(_v)); break;
        case 4: setSelectedTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 5: setSelectable(*reinterpret_cast< bool*>(_v)); break;
        case 6: setSelected(*reinterpret_cast< bool*>(_v)); break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 7;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPAbstractLegendItem::selectionChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPAbstractLegendItem::selectableChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
static const uint qt_meta_data_QCPPlottableLegendItem[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_QCPPlottableLegendItem[] = {
    "QCPPlottableLegendItem\0"
};

const QMetaObject QCPPlottableLegendItem::staticMetaObject = {
    { &QCPAbstractLegendItem::staticMetaObject, qt_meta_stringdata_QCPPlottableLegendItem,
      qt_meta_data_QCPPlottableLegendItem, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPPlottableLegendItem::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPPlottableLegendItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPPlottableLegendItem::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPPlottableLegendItem))
        return static_cast<void*>(const_cast< QCPPlottableLegendItem*>(this));
    return QCPAbstractLegendItem::qt_metacast(_clname);
}

int QCPPlottableLegendItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractLegendItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_QCPLegend[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
      14,   34, // properties
       2,   90, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: signature, parameters, type, tag, flags
      17,   11,   10,   10, 0x05,
      62,   11,   10,   10, 0x05,

 // slots: signature, parameters, type, tag, flags
     124,  108,   10,   10, 0x0a,
     174,  160,   10,   10, 0x0a,

 // properties: name, type, flags
     213,  208, 0x4d095103,
     230,  223, 0x42095103,
     242,  236, 0x40095103,
     254,  247, 0x43095103,
     270,  264, 0x15095103,
     283,  279, 0x02095103,
     299,  208, 0x4d095103,
     108,  313, 0x0049510b,
     160,  313, 0x0049510b,
     329,  208, 0x4d095103,
     347,  208, 0x4d095103,
     369,  223, 0x42095103,
     383,  236, 0x40095103,
     396,  247, 0x43095103,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       1,
       0,
       0,
       0,
       0,
       0,

 // enums: name, flags, count, data
     414, 0x0,    3,   98,
     313, 0x1,    3,  104,

 // enum data: key, value
     429, uint(QCPLegend::spNone),
     436, uint(QCPLegend::spLegendBox),
     448, uint(QCPLegend::spItems),
     429, uint(QCPLegend::spNone),
     436, uint(QCPLegend::spLegendBox),
     448, uint(QCPLegend::spItems),

       0        // eod
};

static const char qt_meta_stringdata_QCPLegend[] = {
    "QCPLegend\0\0parts\0"
    "selectionChanged(QCPLegend::SelectableParts)\0"
    "selectableChanged(QCPLegend::SelectableParts)\0"
    "selectableParts\0setSelectableParts(SelectableParts)\0"
    "selectedParts\0setSelectedParts(SelectableParts)\0"
    "QPen\0borderPen\0QBrush\0brush\0QFont\0"
    "font\0QColor\0textColor\0QSize\0iconSize\0"
    "int\0iconTextPadding\0iconBorderPen\0"
    "SelectableParts\0selectedBorderPen\0"
    "selectedIconBorderPen\0selectedBrush\0"
    "selectedFont\0selectedTextColor\0"
    "SelectablePart\0spNone\0spLegendBox\0"
    "spItems\0"
};

const QMetaObject QCPLegend::staticMetaObject = {
    { &QCPLayoutGrid::staticMetaObject, qt_meta_stringdata_QCPLegend,
      qt_meta_data_QCPLegend, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPLegend::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPLegend::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPLegend::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLegend))
        return static_cast<void*>(const_cast< QCPLegend*>(this));
    return QCPLayoutGrid::qt_metacast(_clname);
}

int QCPLegend::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutGrid::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: selectionChanged((*reinterpret_cast< QCPLegend::SelectableParts(*)>(_a[1]))); break;
        case 1: selectableChanged((*reinterpret_cast< QCPLegend::SelectableParts(*)>(_a[1]))); break;
        case 2: setSelectableParts((*reinterpret_cast< const SelectableParts(*)>(_a[1]))); break;
        case 3: setSelectedParts((*reinterpret_cast< const SelectableParts(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 4;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = borderPen(); break;
        case 1: *reinterpret_cast< QBrush*>(_v) = brush(); break;
        case 2: *reinterpret_cast< QFont*>(_v) = font(); break;
        case 3: *reinterpret_cast< QColor*>(_v) = textColor(); break;
        case 4: *reinterpret_cast< QSize*>(_v) = iconSize(); break;
        case 5: *reinterpret_cast< int*>(_v) = iconTextPadding(); break;
        case 6: *reinterpret_cast< QPen*>(_v) = iconBorderPen(); break;
        case 7: *reinterpret_cast<int*>(_v) = QFlag(selectableParts()); break;
        case 8: *reinterpret_cast<int*>(_v) = QFlag(selectedParts()); break;
        case 9: *reinterpret_cast< QPen*>(_v) = selectedBorderPen(); break;
        case 10: *reinterpret_cast< QPen*>(_v) = selectedIconBorderPen(); break;
        case 11: *reinterpret_cast< QBrush*>(_v) = selectedBrush(); break;
        case 12: *reinterpret_cast< QFont*>(_v) = selectedFont(); break;
        case 13: *reinterpret_cast< QColor*>(_v) = selectedTextColor(); break;
        }
        _id -= 14;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setBorderPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 2: setFont(*reinterpret_cast< QFont*>(_v)); break;
        case 3: setTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 4: setIconSize(*reinterpret_cast< QSize*>(_v)); break;
        case 5: setIconTextPadding(*reinterpret_cast< int*>(_v)); break;
        case 6: setIconBorderPen(*reinterpret_cast< QPen*>(_v)); break;
        case 7: setSelectableParts(QFlag(*reinterpret_cast<int*>(_v))); break;
        case 8: setSelectedParts(QFlag(*reinterpret_cast<int*>(_v))); break;
        case 9: setSelectedBorderPen(*reinterpret_cast< QPen*>(_v)); break;
        case 10: setSelectedIconBorderPen(*reinterpret_cast< QPen*>(_v)); break;
        case 11: setSelectedBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 12: setSelectedFont(*reinterpret_cast< QFont*>(_v)); break;
        case 13: setSelectedTextColor(*reinterpret_cast< QColor*>(_v)); break;
        }
        _id -= 14;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 14;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPLegend::selectionChanged(QCPLegend::SelectableParts _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPLegend::selectableChanged(QCPLegend::SelectableParts _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
static const uint qt_meta_data_QCPTextElement[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       7,   44, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: signature, parameters, type, tag, flags
      25,   16,   15,   15, 0x05,
      59,   48,   15,   15, 0x05,
      89,   83,   15,   15, 0x05,
     111,   83,   15,   15, 0x05,

 // slots: signature, parameters, type, tag, flags
     139,   48,   15,   15, 0x0a,
     159,   16,   15,   15, 0x0a,

 // properties: name, type, flags
     185,  177, 0x0a095103,
     196,  190, 0x40095103,
     208,  201, 0x43095103,
     218,  190, 0x40095103,
     231,  201, 0x43095103,
      48,  249, 0x01495103,
      16,  249, 0x01495103,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,
       1,
       0,

       0        // eod
};

static const char qt_meta_stringdata_QCPTextElement[] = {
    "QCPTextElement\0\0selected\0"
    "selectionChanged(bool)\0selectable\0"
    "selectableChanged(bool)\0event\0"
    "clicked(QMouseEvent*)\0doubleClicked(QMouseEvent*)\0"
    "setSelectable(bool)\0setSelected(bool)\0"
    "QString\0text\0QFont\0font\0QColor\0textColor\0"
    "selectedFont\0selectedTextColor\0bool\0"
};

const QMetaObject QCPTextElement::staticMetaObject = {
    { &QCPLayoutElement::staticMetaObject, qt_meta_stringdata_QCPTextElement,
      qt_meta_data_QCPTextElement, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPTextElement::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPTextElement::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPTextElement::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPTextElement))
        return static_cast<void*>(const_cast< QCPTextElement*>(this));
    return QCPLayoutElement::qt_metacast(_clname);
}

int QCPTextElement::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutElement::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: selectionChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: selectableChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: clicked((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 3: doubleClicked((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 4: setSelectable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: setSelected((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 6;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = text(); break;
        case 1: *reinterpret_cast< QFont*>(_v) = font(); break;
        case 2: *reinterpret_cast< QColor*>(_v) = textColor(); break;
        case 3: *reinterpret_cast< QFont*>(_v) = selectedFont(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = selectedTextColor(); break;
        case 5: *reinterpret_cast< bool*>(_v) = selectable(); break;
        case 6: *reinterpret_cast< bool*>(_v) = selected(); break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setText(*reinterpret_cast< QString*>(_v)); break;
        case 1: setFont(*reinterpret_cast< QFont*>(_v)); break;
        case 2: setTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 3: setSelectedFont(*reinterpret_cast< QFont*>(_v)); break;
        case 4: setSelectedTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 5: setSelectable(*reinterpret_cast< bool*>(_v)); break;
        case 6: setSelected(*reinterpret_cast< bool*>(_v)); break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 7;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPTextElement::selectionChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPTextElement::selectableChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPTextElement::clicked(QMouseEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void QCPTextElement::doubleClicked(QMouseEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
static const uint qt_meta_data_QCPColorScaleAxisRectPrivate[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      44,   30,   29,   29, 0x09,
     107,   91,   29,   29, 0x09,

       0        // eod
};

static const char qt_meta_stringdata_QCPColorScaleAxisRectPrivate[] = {
    "QCPColorScaleAxisRectPrivate\0\0"
    "selectedParts\0"
    "axisSelectionChanged(QCPAxis::SelectableParts)\0"
    "selectableParts\0"
    "axisSelectableChanged(QCPAxis::SelectableParts)\0"
};

const QMetaObject QCPColorScaleAxisRectPrivate::staticMetaObject = {
    { &QCPAxisRect::staticMetaObject, qt_meta_stringdata_QCPColorScaleAxisRectPrivate,
      qt_meta_data_QCPColorScaleAxisRectPrivate, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPColorScaleAxisRectPrivate::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPColorScaleAxisRectPrivate::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPColorScaleAxisRectPrivate::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPColorScaleAxisRectPrivate))
        return static_cast<void*>(const_cast< QCPColorScaleAxisRectPrivate*>(this));
    return QCPAxisRect::qt_metacast(_clname);
}

int QCPColorScaleAxisRectPrivate::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAxisRect::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: axisSelectionChanged((*reinterpret_cast< QCPAxis::SelectableParts(*)>(_a[1]))); break;
        case 1: axisSelectableChanged((*reinterpret_cast< QCPAxis::SelectableParts(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 2;
    }
    return _id;
}
static const uint qt_meta_data_QCPColorScale[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       8,   44, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: signature, parameters, type, tag, flags
      24,   15,   14,   14, 0x05,
      61,   51,   14,   14, 0x05,
     114,  102,   14,   14, 0x05,

 // slots: signature, parameters, type, tag, flags
     158,  148,   14,   14, 0x0a,
     181,   51,   14,   14, 0x0a,
     227,  218,   14,   14, 0x0a,

 // properties: name, type, flags
     275,  257, 0x0009510b,
     148,  280, 0x0049510b,
     308,  289, 0x0049510b,
     218,  322, 0x0049510b,
     347,  339, 0x0a095103,
     357,  353, 0x02095103,
     371,  366, 0x01095103,
     381,  366, 0x01095103,

 // properties: notify_signal_id
       0,
       0,
       1,
       2,
       0,
       0,
       0,
       0,

       0        // eod
};

static const char qt_meta_stringdata_QCPColorScale[] = {
    "QCPColorScale\0\0newRange\0"
    "dataRangeChanged(QCPRange)\0scaleType\0"
    "dataScaleTypeChanged(QCPAxis::ScaleType)\0"
    "newGradient\0gradientChanged(QCPColorGradient)\0"
    "dataRange\0setDataRange(QCPRange)\0"
    "setDataScaleType(QCPAxis::ScaleType)\0"
    "gradient\0setGradient(QCPColorGradient)\0"
    "QCPAxis::AxisType\0type\0QCPRange\0"
    "QCPAxis::ScaleType\0dataScaleType\0"
    "QCPColorGradient\0QString\0label\0int\0"
    "barWidth\0bool\0rangeDrag\0rangeZoom\0"
};

const QMetaObject QCPColorScale::staticMetaObject = {
    { &QCPLayoutElement::staticMetaObject, qt_meta_stringdata_QCPColorScale,
      qt_meta_data_QCPColorScale, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPColorScale::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPColorScale::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPColorScale::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPColorScale))
        return static_cast<void*>(const_cast< QCPColorScale*>(this));
    return QCPLayoutElement::qt_metacast(_clname);
}

int QCPColorScale::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutElement::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: dataRangeChanged((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 1: dataScaleTypeChanged((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 2: gradientChanged((*reinterpret_cast< const QCPColorGradient(*)>(_a[1]))); break;
        case 3: setDataRange((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 4: setDataScaleType((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 5: setGradient((*reinterpret_cast< const QCPColorGradient(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 6;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCPAxis::AxisType*>(_v) = type(); break;
        case 1: *reinterpret_cast< QCPRange*>(_v) = dataRange(); break;
        case 2: *reinterpret_cast< QCPAxis::ScaleType*>(_v) = dataScaleType(); break;
        case 3: *reinterpret_cast< QCPColorGradient*>(_v) = gradient(); break;
        case 4: *reinterpret_cast< QString*>(_v) = label(); break;
        case 5: *reinterpret_cast< int*>(_v) = barWidth(); break;
        case 6: *reinterpret_cast< bool*>(_v) = rangeDrag(); break;
        case 7: *reinterpret_cast< bool*>(_v) = rangeZoom(); break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setType(*reinterpret_cast< QCPAxis::AxisType*>(_v)); break;
        case 1: setDataRange(*reinterpret_cast< QCPRange*>(_v)); break;
        case 2: setDataScaleType(*reinterpret_cast< QCPAxis::ScaleType*>(_v)); break;
        case 3: setGradient(*reinterpret_cast< QCPColorGradient*>(_v)); break;
        case 4: setLabel(*reinterpret_cast< QString*>(_v)); break;
        case 5: setBarWidth(*reinterpret_cast< int*>(_v)); break;
        case 6: setRangeDrag(*reinterpret_cast< bool*>(_v)); break;
        case 7: setRangeZoom(*reinterpret_cast< bool*>(_v)); break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 8;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPColorScale::dataRangeChanged(const QCPRange & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPColorScale::dataScaleTypeChanged(QCPAxis::ScaleType _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPColorScale::gradientChanged(const QCPColorGradient & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
static const uint qt_meta_data_QCPGraph[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       5,   14, // properties
       1,   29, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      19,    9, 0x0009510b,
      45,   29, 0x0009510b,
      62,   58, 0x02095103,
      84,   74, 0x0009510b,
     106,  101, 0x01095103,

 // enums: name, flags, count, data
       9, 0x0,    6,   33,

 // enum data: key, value
     123, uint(QCPGraph::lsNone),
     130, uint(QCPGraph::lsLine),
     137, uint(QCPGraph::lsStepLeft),
     148, uint(QCPGraph::lsStepRight),
     160, uint(QCPGraph::lsStepCenter),
     173, uint(QCPGraph::lsImpulse),

       0        // eod
};

static const char qt_meta_stringdata_QCPGraph[] = {
    "QCPGraph\0LineStyle\0lineStyle\0"
    "QCPScatterStyle\0scatterStyle\0int\0"
    "scatterSkip\0QCPGraph*\0channelFillGraph\0"
    "bool\0adaptiveSampling\0lsNone\0lsLine\0"
    "lsStepLeft\0lsStepRight\0lsStepCenter\0"
    "lsImpulse\0"
};

const QMetaObject QCPGraph::staticMetaObject = {
    { &QCPAbstractPlottable1D<QCPGraphData>::staticMetaObject, qt_meta_stringdata_QCPGraph,
      qt_meta_data_QCPGraph, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPGraph::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPGraph::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPGraph::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPGraph))
        return static_cast<void*>(const_cast< QCPGraph*>(this));
    return QCPAbstractPlottable1D<QCPGraphData>::qt_metacast(_clname);
}

int QCPGraph::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable1D<QCPGraphData>::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< LineStyle*>(_v) = lineStyle(); break;
        case 1: *reinterpret_cast< QCPScatterStyle*>(_v) = scatterStyle(); break;
        case 2: *reinterpret_cast< int*>(_v) = scatterSkip(); break;
        case 3: *reinterpret_cast< QCPGraph**>(_v) = channelFillGraph(); break;
        case 4: *reinterpret_cast< bool*>(_v) = adaptiveSampling(); break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setLineStyle(*reinterpret_cast< LineStyle*>(_v)); break;
        case 1: setScatterStyle(*reinterpret_cast< QCPScatterStyle*>(_v)); break;
        case 2: setScatterSkip(*reinterpret_cast< int*>(_v)); break;
        case 3: setChannelFillGraph(*reinterpret_cast< QCPGraph**>(_v)); break;
        case 4: setAdaptiveSampling(*reinterpret_cast< bool*>(_v)); break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPCurve[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       3,   14, // properties
       1,   23, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      25,    9, 0x0009510b,
      42,   38, 0x02095103,
      64,   54, 0x0009510b,

 // enums: name, flags, count, data
      54, 0x0,    2,   27,

 // enum data: key, value
      74, uint(QCPCurve::lsNone),
      81, uint(QCPCurve::lsLine),

       0        // eod
};

static const char qt_meta_stringdata_QCPCurve[] = {
    "QCPCurve\0QCPScatterStyle\0scatterStyle\0"
    "int\0scatterSkip\0LineStyle\0lineStyle\0"
    "lsNone\0lsLine\0"
};

const QMetaObject QCPCurve::staticMetaObject = {
    { &QCPAbstractPlottable1D<QCPCurveData>::staticMetaObject, qt_meta_stringdata_QCPCurve,
      qt_meta_data_QCPCurve, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPCurve::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPCurve::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPCurve::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPCurve))
        return static_cast<void*>(const_cast< QCPCurve*>(this));
    return QCPAbstractPlottable1D<QCPCurveData>::qt_metacast(_clname);
}

int QCPCurve::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable1D<QCPCurveData>::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCPScatterStyle*>(_v) = scatterStyle(); break;
        case 1: *reinterpret_cast< int*>(_v) = scatterSkip(); break;
        case 2: *reinterpret_cast< LineStyle*>(_v) = lineStyle(); break;
        }
        _id -= 3;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setScatterStyle(*reinterpret_cast< QCPScatterStyle*>(_v)); break;
        case 1: setScatterSkip(*reinterpret_cast< int*>(_v)); break;
        case 2: setLineStyle(*reinterpret_cast< LineStyle*>(_v)); break;
        }
        _id -= 3;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 3;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPBarsGroup[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       2,   14, // properties
       1,   20, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      25,   13, 0x0009510b,
      44,   37, 0x06095103,

 // enums: name, flags, count, data
      13, 0x0,    3,   24,

 // enum data: key, value
      52, uint(QCPBarsGroup::stAbsolute),
      63, uint(QCPBarsGroup::stAxisRectRatio),
      79, uint(QCPBarsGroup::stPlotCoords),

       0        // eod
};

static const char qt_meta_stringdata_QCPBarsGroup[] = {
    "QCPBarsGroup\0SpacingType\0spacingType\0"
    "double\0spacing\0stAbsolute\0stAxisRectRatio\0"
    "stPlotCoords\0"
};

const QMetaObject QCPBarsGroup::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QCPBarsGroup,
      qt_meta_data_QCPBarsGroup, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPBarsGroup::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPBarsGroup::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPBarsGroup::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPBarsGroup))
        return static_cast<void*>(const_cast< QCPBarsGroup*>(this));
    return QObject::qt_metacast(_clname);
}

int QCPBarsGroup::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< SpacingType*>(_v) = spacingType(); break;
        case 1: *reinterpret_cast< double*>(_v) = spacing(); break;
        }
        _id -= 2;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setSpacingType(*reinterpret_cast< SpacingType*>(_v)); break;
        case 1: setSpacing(*reinterpret_cast< double*>(_v)); break;
        }
        _id -= 2;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 2;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPBars[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       7,   14, // properties
       1,   35, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      15,    8, 0x06095103,
      31,   21, 0x0009510b,
      55,   41, 0x0009510b,
      65,    8, 0x06095103,
      75,    8, 0x06095103,
      96,   87, 0x00095009,
     105,   87, 0x00095009,

 // enums: name, flags, count, data
      21, 0x0,    3,   39,

 // enum data: key, value
     114, uint(QCPBars::wtAbsolute),
     125, uint(QCPBars::wtAxisRectRatio),
     141, uint(QCPBars::wtPlotCoords),

       0        // eod
};

static const char qt_meta_stringdata_QCPBars[] = {
    "QCPBars\0double\0width\0WidthType\0widthType\0"
    "QCPBarsGroup*\0barsGroup\0baseValue\0"
    "stackingGap\0QCPBars*\0barBelow\0barAbove\0"
    "wtAbsolute\0wtAxisRectRatio\0wtPlotCoords\0"
};

const QMetaObject QCPBars::staticMetaObject = {
    { &QCPAbstractPlottable1D<QCPBarsData>::staticMetaObject, qt_meta_stringdata_QCPBars,
      qt_meta_data_QCPBars, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPBars::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPBars::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPBars::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPBars))
        return static_cast<void*>(const_cast< QCPBars*>(this));
    return QCPAbstractPlottable1D<QCPBarsData>::qt_metacast(_clname);
}

int QCPBars::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable1D<QCPBarsData>::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< double*>(_v) = width(); break;
        case 1: *reinterpret_cast< WidthType*>(_v) = widthType(); break;
        case 2: *reinterpret_cast< QCPBarsGroup**>(_v) = barsGroup(); break;
        case 3: *reinterpret_cast< double*>(_v) = baseValue(); break;
        case 4: *reinterpret_cast< double*>(_v) = stackingGap(); break;
        case 5: *reinterpret_cast< QCPBars**>(_v) = barBelow(); break;
        case 6: *reinterpret_cast< QCPBars**>(_v) = barAbove(); break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setWidth(*reinterpret_cast< double*>(_v)); break;
        case 1: setWidthType(*reinterpret_cast< WidthType*>(_v)); break;
        case 2: setBarsGroup(*reinterpret_cast< QCPBarsGroup**>(_v)); break;
        case 3: setBaseValue(*reinterpret_cast< double*>(_v)); break;
        case 4: setStackingGap(*reinterpret_cast< double*>(_v)); break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 7;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPStatisticalBox[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       7,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      25,   18, 0x06095103,
      31,   18, 0x06095103,
      49,   44, 0x4d095103,
      60,   44, 0x4d095103,
      79,   74, 0x01095103,
      98,   44, 0x4d095103,
     124,  108, 0x0009510b,

       0        // eod
};

static const char qt_meta_stringdata_QCPStatisticalBox[] = {
    "QCPStatisticalBox\0double\0width\0"
    "whiskerWidth\0QPen\0whiskerPen\0whiskerBarPen\0"
    "bool\0whiskerAntialiased\0medianPen\0"
    "QCPScatterStyle\0outlierStyle\0"
};

const QMetaObject QCPStatisticalBox::staticMetaObject = {
    { &QCPAbstractPlottable1D<QCPStatisticalBoxData>::staticMetaObject, qt_meta_stringdata_QCPStatisticalBox,
      qt_meta_data_QCPStatisticalBox, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPStatisticalBox::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPStatisticalBox::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPStatisticalBox::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPStatisticalBox))
        return static_cast<void*>(const_cast< QCPStatisticalBox*>(this));
    return QCPAbstractPlottable1D<QCPStatisticalBoxData>::qt_metacast(_clname);
}

int QCPStatisticalBox::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable1D<QCPStatisticalBoxData>::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< double*>(_v) = width(); break;
        case 1: *reinterpret_cast< double*>(_v) = whiskerWidth(); break;
        case 2: *reinterpret_cast< QPen*>(_v) = whiskerPen(); break;
        case 3: *reinterpret_cast< QPen*>(_v) = whiskerBarPen(); break;
        case 4: *reinterpret_cast< bool*>(_v) = whiskerAntialiased(); break;
        case 5: *reinterpret_cast< QPen*>(_v) = medianPen(); break;
        case 6: *reinterpret_cast< QCPScatterStyle*>(_v) = outlierStyle(); break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setWidth(*reinterpret_cast< double*>(_v)); break;
        case 1: setWhiskerWidth(*reinterpret_cast< double*>(_v)); break;
        case 2: setWhiskerPen(*reinterpret_cast< QPen*>(_v)); break;
        case 3: setWhiskerBarPen(*reinterpret_cast< QPen*>(_v)); break;
        case 4: setWhiskerAntialiased(*reinterpret_cast< bool*>(_v)); break;
        case 5: setMedianPen(*reinterpret_cast< QPen*>(_v)); break;
        case 6: setOutlierStyle(*reinterpret_cast< QCPScatterStyle*>(_v)); break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 7;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPColorMap[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       6,   59, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: signature, parameters, type, tag, flags
      22,   13,   12,   12, 0x05,
      59,   49,   12,   12, 0x05,
     112,  100,   12,   12, 0x05,

 // slots: signature, parameters, type, tag, flags
     156,  146,   12,   12, 0x0a,
     179,   49,   12,   12, 0x0a,
     225,  216,   12,   12, 0x0a,
     279,  255,   12,   12, 0x0a,
     340,  326,   12,   12, 0x2a,
     381,   12,   12,   12, 0x2a,

 // properties: name, type, flags
     146,  400, 0x0049510b,
     428,  409, 0x0049510b,
     216,  442, 0x0049510b,
     464,  459, 0x01095103,
     476,  459, 0x01095103,
     505,  490, 0x0009510b,

 // properties: notify_signal_id
       0,
       1,
       2,
       0,
       0,
       0,

       0        // eod
};

static const char qt_meta_stringdata_QCPColorMap[] = {
    "QCPColorMap\0\0newRange\0dataRangeChanged(QCPRange)\0"
    "scaleType\0dataScaleTypeChanged(QCPAxis::ScaleType)\0"
    "newGradient\0gradientChanged(QCPColorGradient)\0"
    "dataRange\0setDataRange(QCPRange)\0"
    "setDataScaleType(QCPAxis::ScaleType)\0"
    "gradient\0setGradient(QCPColorGradient)\0"
    "transformMode,thumbSize\0"
    "updateLegendIcon(Qt::TransformationMode,QSize)\0"
    "transformMode\0updateLegendIcon(Qt::TransformationMode)\0"
    "updateLegendIcon()\0QCPRange\0"
    "QCPAxis::ScaleType\0dataScaleType\0"
    "QCPColorGradient\0bool\0interpolate\0"
    "tightBoundary\0QCPColorScale*\0colorScale\0"
};

const QMetaObject QCPColorMap::staticMetaObject = {
    { &QCPAbstractPlottable::staticMetaObject, qt_meta_stringdata_QCPColorMap,
      qt_meta_data_QCPColorMap, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPColorMap::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPColorMap::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPColorMap::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPColorMap))
        return static_cast<void*>(const_cast< QCPColorMap*>(this));
    return QCPAbstractPlottable::qt_metacast(_clname);
}

int QCPColorMap::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: dataRangeChanged((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 1: dataScaleTypeChanged((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 2: gradientChanged((*reinterpret_cast< const QCPColorGradient(*)>(_a[1]))); break;
        case 3: setDataRange((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 4: setDataScaleType((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 5: setGradient((*reinterpret_cast< const QCPColorGradient(*)>(_a[1]))); break;
        case 6: updateLegendIcon((*reinterpret_cast< Qt::TransformationMode(*)>(_a[1])),(*reinterpret_cast< const QSize(*)>(_a[2]))); break;
        case 7: updateLegendIcon((*reinterpret_cast< Qt::TransformationMode(*)>(_a[1]))); break;
        case 8: updateLegendIcon(); break;
        default: ;
        }
        _id -= 9;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCPRange*>(_v) = dataRange(); break;
        case 1: *reinterpret_cast< QCPAxis::ScaleType*>(_v) = dataScaleType(); break;
        case 2: *reinterpret_cast< QCPColorGradient*>(_v) = gradient(); break;
        case 3: *reinterpret_cast< bool*>(_v) = interpolate(); break;
        case 4: *reinterpret_cast< bool*>(_v) = tightBoundary(); break;
        case 5: *reinterpret_cast< QCPColorScale**>(_v) = colorScale(); break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setDataRange(*reinterpret_cast< QCPRange*>(_v)); break;
        case 1: setDataScaleType(*reinterpret_cast< QCPAxis::ScaleType*>(_v)); break;
        case 2: setGradient(*reinterpret_cast< QCPColorGradient*>(_v)); break;
        case 3: setInterpolate(*reinterpret_cast< bool*>(_v)); break;
        case 4: setTightBoundary(*reinterpret_cast< bool*>(_v)); break;
        case 5: setColorScale(*reinterpret_cast< QCPColorScale**>(_v)); break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 6;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPColorMap::dataRangeChanged(const QCPRange & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPColorMap::dataScaleTypeChanged(QCPAxis::ScaleType _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPColorMap::gradientChanged(const QCPColorGradient & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
static const uint qt_meta_data_QCPFinancial[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       8,   14, // properties
       2,   38, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      24,   13, 0x0009510b,
      42,   35, 0x06095103,
      58,   48, 0x0009510b,
      73,   68, 0x01095103,
      91,   84, 0x42095103,
     105,   84, 0x42095103,
     124,  119, 0x4d095103,
     136,  119, 0x4d095103,

 // enums: name, flags, count, data
      48, 0x0,    3,   46,
      13, 0x0,    2,   52,

 // enum data: key, value
     148, uint(QCPFinancial::wtAbsolute),
     159, uint(QCPFinancial::wtAxisRectRatio),
     175, uint(QCPFinancial::wtPlotCoords),
     188, uint(QCPFinancial::csOhlc),
     195, uint(QCPFinancial::csCandlestick),

       0        // eod
};

static const char qt_meta_stringdata_QCPFinancial[] = {
    "QCPFinancial\0ChartStyle\0chartStyle\0"
    "double\0width\0WidthType\0widthType\0bool\0"
    "twoColored\0QBrush\0brushPositive\0"
    "brushNegative\0QPen\0penPositive\0"
    "penNegative\0wtAbsolute\0wtAxisRectRatio\0"
    "wtPlotCoords\0csOhlc\0csCandlestick\0"
};

const QMetaObject QCPFinancial::staticMetaObject = {
    { &QCPAbstractPlottable1D<QCPFinancialData>::staticMetaObject, qt_meta_stringdata_QCPFinancial,
      qt_meta_data_QCPFinancial, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPFinancial::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPFinancial::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPFinancial::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPFinancial))
        return static_cast<void*>(const_cast< QCPFinancial*>(this));
    return QCPAbstractPlottable1D<QCPFinancialData>::qt_metacast(_clname);
}

int QCPFinancial::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable1D<QCPFinancialData>::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< ChartStyle*>(_v) = chartStyle(); break;
        case 1: *reinterpret_cast< double*>(_v) = width(); break;
        case 2: *reinterpret_cast< WidthType*>(_v) = widthType(); break;
        case 3: *reinterpret_cast< bool*>(_v) = twoColored(); break;
        case 4: *reinterpret_cast< QBrush*>(_v) = brushPositive(); break;
        case 5: *reinterpret_cast< QBrush*>(_v) = brushNegative(); break;
        case 6: *reinterpret_cast< QPen*>(_v) = penPositive(); break;
        case 7: *reinterpret_cast< QPen*>(_v) = penNegative(); break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setChartStyle(*reinterpret_cast< ChartStyle*>(_v)); break;
        case 1: setWidth(*reinterpret_cast< double*>(_v)); break;
        case 2: setWidthType(*reinterpret_cast< WidthType*>(_v)); break;
        case 3: setTwoColored(*reinterpret_cast< bool*>(_v)); break;
        case 4: setBrushPositive(*reinterpret_cast< QBrush*>(_v)); break;
        case 5: setBrushNegative(*reinterpret_cast< QBrush*>(_v)); break;
        case 6: setPenPositive(*reinterpret_cast< QPen*>(_v)); break;
        case 7: setPenNegative(*reinterpret_cast< QPen*>(_v)); break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 8;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPErrorBars[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       5,   14, // properties
       1,   29, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      55,   13, 0x0009510b,
      82,   60, 0x0009510b,
     106,   96, 0x0009510b,
     123,  116, 0x06095103,
     136,  116, 0x06095103,

 // enums: name, flags, count, data
      96, 0x0,    2,   33,

 // enum data: key, value
     146, uint(QCPErrorBars::etKeyError),
     157, uint(QCPErrorBars::etValueError),

       0        // eod
};

static const char qt_meta_stringdata_QCPErrorBars[] = {
    "QCPErrorBars\0QSharedPointer<QCPErrorBarsDataContainer>\0"
    "data\0QCPAbstractPlottable*\0dataPlottable\0"
    "ErrorType\0errorType\0double\0whiskerWidth\0"
    "symbolGap\0etKeyError\0etValueError\0"
};

const QMetaObject QCPErrorBars::staticMetaObject = {
    { &QCPAbstractPlottable::staticMetaObject, qt_meta_stringdata_QCPErrorBars,
      qt_meta_data_QCPErrorBars, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPErrorBars::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPErrorBars::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPErrorBars::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPErrorBars))
        return static_cast<void*>(const_cast< QCPErrorBars*>(this));
    if (!strcmp(_clname, "QCPPlottableInterface1D"))
        return static_cast< QCPPlottableInterface1D*>(const_cast< QCPErrorBars*>(this));
    return QCPAbstractPlottable::qt_metacast(_clname);
}

int QCPErrorBars::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QSharedPointer<QCPErrorBarsDataContainer>*>(_v) = data(); break;
        case 1: *reinterpret_cast< QCPAbstractPlottable**>(_v) = dataPlottable(); break;
        case 2: *reinterpret_cast< ErrorType*>(_v) = errorType(); break;
        case 3: *reinterpret_cast< double*>(_v) = whiskerWidth(); break;
        case 4: *reinterpret_cast< double*>(_v) = symbolGap(); break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setData(*reinterpret_cast< QSharedPointer<QCPErrorBarsDataContainer>*>(_v)); break;
        case 1: setDataPlottable(*reinterpret_cast< QCPAbstractPlottable**>(_v)); break;
        case 2: setErrorType(*reinterpret_cast< ErrorType*>(_v)); break;
        case 3: setWhiskerWidth(*reinterpret_cast< double*>(_v)); break;
        case 4: setSymbolGap(*reinterpret_cast< double*>(_v)); break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPItemStraightLine[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       2,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      25,   20, 0x4d095103,
      29,   20, 0x4d095103,

       0        // eod
};

static const char qt_meta_stringdata_QCPItemStraightLine[] = {
    "QCPItemStraightLine\0QPen\0pen\0selectedPen\0"
};

const QMetaObject QCPItemStraightLine::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemStraightLine,
      qt_meta_data_QCPItemStraightLine, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPItemStraightLine::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPItemStraightLine::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPItemStraightLine::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemStraightLine))
        return static_cast<void*>(const_cast< QCPItemStraightLine*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemStraightLine::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        }
        _id -= 2;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        }
        _id -= 2;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 2;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPItemLine[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       4,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      17,   12, 0x4d095103,
      21,   12, 0x4d095103,
      47,   33, 0x0009510b,
      52,   33, 0x0009510b,

       0        // eod
};

static const char qt_meta_stringdata_QCPItemLine[] = {
    "QCPItemLine\0QPen\0pen\0selectedPen\0"
    "QCPLineEnding\0head\0tail\0"
};

const QMetaObject QCPItemLine::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemLine,
      qt_meta_data_QCPItemLine, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPItemLine::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPItemLine::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPItemLine::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemLine))
        return static_cast<void*>(const_cast< QCPItemLine*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemLine::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        case 2: *reinterpret_cast< QCPLineEnding*>(_v) = head(); break;
        case 3: *reinterpret_cast< QCPLineEnding*>(_v) = tail(); break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: setHead(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        case 3: setTail(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPItemCurve[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       4,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      18,   13, 0x4d095103,
      22,   13, 0x4d095103,
      48,   34, 0x0009510b,
      53,   34, 0x0009510b,

       0        // eod
};

static const char qt_meta_stringdata_QCPItemCurve[] = {
    "QCPItemCurve\0QPen\0pen\0selectedPen\0"
    "QCPLineEnding\0head\0tail\0"
};

const QMetaObject QCPItemCurve::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemCurve,
      qt_meta_data_QCPItemCurve, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPItemCurve::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPItemCurve::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPItemCurve::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemCurve))
        return static_cast<void*>(const_cast< QCPItemCurve*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemCurve::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        case 2: *reinterpret_cast< QCPLineEnding*>(_v) = head(); break;
        case 3: *reinterpret_cast< QCPLineEnding*>(_v) = tail(); break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: setHead(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        case 3: setTail(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPItemRect[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       4,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      17,   12, 0x4d095103,
      21,   12, 0x4d095103,
      40,   33, 0x42095103,
      46,   33, 0x42095103,

       0        // eod
};

static const char qt_meta_stringdata_QCPItemRect[] = {
    "QCPItemRect\0QPen\0pen\0selectedPen\0"
    "QBrush\0brush\0selectedBrush\0"
};

const QMetaObject QCPItemRect::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemRect,
      qt_meta_data_QCPItemRect, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPItemRect::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPItemRect::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPItemRect::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemRect))
        return static_cast<void*>(const_cast< QCPItemRect*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemRect::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        case 2: *reinterpret_cast< QBrush*>(_v) = brush(); break;
        case 3: *reinterpret_cast< QBrush*>(_v) = selectedBrush(); break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 3: setSelectedBrush(*reinterpret_cast< QBrush*>(_v)); break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPItemText[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
      13,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      19,   12, 0x43095103,
      25,   12, 0x43095103,
      44,   39, 0x4d095103,
      48,   39, 0x4d095103,
      67,   60, 0x42095103,
      73,   60, 0x42095103,
      93,   87, 0x40095103,
      98,   87, 0x40095103,
     119,  111, 0x0a095103,
     138,  124, 0x0009510b,
     156,  124, 0x0009510b,
     177,  170, 0x06095103,
     195,  186, 0x0009510b,

       0        // eod
};

static const char qt_meta_stringdata_QCPItemText[] = {
    "QCPItemText\0QColor\0color\0selectedColor\0"
    "QPen\0pen\0selectedPen\0QBrush\0brush\0"
    "selectedBrush\0QFont\0font\0selectedFont\0"
    "QString\0text\0Qt::Alignment\0positionAlignment\0"
    "textAlignment\0double\0rotation\0QMargins\0"
    "padding\0"
};

const QMetaObject QCPItemText::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemText,
      qt_meta_data_QCPItemText, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPItemText::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPItemText::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPItemText::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemText))
        return static_cast<void*>(const_cast< QCPItemText*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemText::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QColor*>(_v) = color(); break;
        case 1: *reinterpret_cast< QColor*>(_v) = selectedColor(); break;
        case 2: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 3: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        case 4: *reinterpret_cast< QBrush*>(_v) = brush(); break;
        case 5: *reinterpret_cast< QBrush*>(_v) = selectedBrush(); break;
        case 6: *reinterpret_cast< QFont*>(_v) = font(); break;
        case 7: *reinterpret_cast< QFont*>(_v) = selectedFont(); break;
        case 8: *reinterpret_cast< QString*>(_v) = text(); break;
        case 9: *reinterpret_cast< Qt::Alignment*>(_v) = positionAlignment(); break;
        case 10: *reinterpret_cast< Qt::Alignment*>(_v) = textAlignment(); break;
        case 11: *reinterpret_cast< double*>(_v) = rotation(); break;
        case 12: *reinterpret_cast< QMargins*>(_v) = padding(); break;
        }
        _id -= 13;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setColor(*reinterpret_cast< QColor*>(_v)); break;
        case 1: setSelectedColor(*reinterpret_cast< QColor*>(_v)); break;
        case 2: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 3: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 4: setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 5: setSelectedBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 6: setFont(*reinterpret_cast< QFont*>(_v)); break;
        case 7: setSelectedFont(*reinterpret_cast< QFont*>(_v)); break;
        case 8: setText(*reinterpret_cast< QString*>(_v)); break;
        case 9: setPositionAlignment(*reinterpret_cast< Qt::Alignment*>(_v)); break;
        case 10: setTextAlignment(*reinterpret_cast< Qt::Alignment*>(_v)); break;
        case 11: setRotation(*reinterpret_cast< double*>(_v)); break;
        case 12: setPadding(*reinterpret_cast< QMargins*>(_v)); break;
        }
        _id -= 13;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 13;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPItemEllipse[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       4,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      20,   15, 0x4d095103,
      24,   15, 0x4d095103,
      43,   36, 0x42095103,
      49,   36, 0x42095103,

       0        // eod
};

static const char qt_meta_stringdata_QCPItemEllipse[] = {
    "QCPItemEllipse\0QPen\0pen\0selectedPen\0"
    "QBrush\0brush\0selectedBrush\0"
};

const QMetaObject QCPItemEllipse::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemEllipse,
      qt_meta_data_QCPItemEllipse, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPItemEllipse::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPItemEllipse::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPItemEllipse::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemEllipse))
        return static_cast<void*>(const_cast< QCPItemEllipse*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemEllipse::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        case 2: *reinterpret_cast< QBrush*>(_v) = brush(); break;
        case 3: *reinterpret_cast< QBrush*>(_v) = selectedBrush(); break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 3: setSelectedBrush(*reinterpret_cast< QBrush*>(_v)); break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPItemPixmap[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       6,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      22,   14, 0x41095103,
      34,   29, 0x01095103,
      61,   41, 0x00095009,
     100,   77, 0x00095009,
     124,  119, 0x4d095103,
     128,  119, 0x4d095103,

       0        // eod
};

static const char qt_meta_stringdata_QCPItemPixmap[] = {
    "QCPItemPixmap\0QPixmap\0pixmap\0bool\0"
    "scaled\0Qt::AspectRatioMode\0aspectRatioMode\0"
    "Qt::TransformationMode\0transformationMode\0"
    "QPen\0pen\0selectedPen\0"
};

const QMetaObject QCPItemPixmap::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemPixmap,
      qt_meta_data_QCPItemPixmap, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPItemPixmap::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPItemPixmap::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPItemPixmap::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemPixmap))
        return static_cast<void*>(const_cast< QCPItemPixmap*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemPixmap::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPixmap*>(_v) = pixmap(); break;
        case 1: *reinterpret_cast< bool*>(_v) = scaled(); break;
        case 2: *reinterpret_cast< Qt::AspectRatioMode*>(_v) = aspectRatioMode(); break;
        case 3: *reinterpret_cast< Qt::TransformationMode*>(_v) = transformationMode(); break;
        case 4: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 5: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPixmap(*reinterpret_cast< QPixmap*>(_v)); break;
        case 1: setScaled(*reinterpret_cast< bool*>(_v)); break;
        case 4: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 5: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 6;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPItemTracer[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       9,   14, // properties
       1,   41, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      19,   14, 0x4d095103,
      23,   14, 0x4d095103,
      42,   35, 0x42095103,
      48,   35, 0x42095103,
      69,   62, 0x06095103,
      86,   74, 0x0009510b,
     102,   92, 0x0009510b,
     108,   62, 0x06095103,
     122,  117, 0x01095103,

 // enums: name, flags, count, data
      74, 0x0,    5,   45,

 // enum data: key, value
     136, uint(QCPItemTracer::tsNone),
     143, uint(QCPItemTracer::tsPlus),
     150, uint(QCPItemTracer::tsCrosshair),
     162, uint(QCPItemTracer::tsCircle),
     171, uint(QCPItemTracer::tsSquare),

       0        // eod
};

static const char qt_meta_stringdata_QCPItemTracer[] = {
    "QCPItemTracer\0QPen\0pen\0selectedPen\0"
    "QBrush\0brush\0selectedBrush\0double\0"
    "size\0TracerStyle\0style\0QCPGraph*\0graph\0"
    "graphKey\0bool\0interpolating\0tsNone\0"
    "tsPlus\0tsCrosshair\0tsCircle\0tsSquare\0"
};

const QMetaObject QCPItemTracer::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemTracer,
      qt_meta_data_QCPItemTracer, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPItemTracer::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPItemTracer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPItemTracer::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemTracer))
        return static_cast<void*>(const_cast< QCPItemTracer*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemTracer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        case 2: *reinterpret_cast< QBrush*>(_v) = brush(); break;
        case 3: *reinterpret_cast< QBrush*>(_v) = selectedBrush(); break;
        case 4: *reinterpret_cast< double*>(_v) = size(); break;
        case 5: *reinterpret_cast< TracerStyle*>(_v) = style(); break;
        case 6: *reinterpret_cast< QCPGraph**>(_v) = graph(); break;
        case 7: *reinterpret_cast< double*>(_v) = graphKey(); break;
        case 8: *reinterpret_cast< bool*>(_v) = interpolating(); break;
        }
        _id -= 9;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 3: setSelectedBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 4: setSize(*reinterpret_cast< double*>(_v)); break;
        case 5: setStyle(*reinterpret_cast< TracerStyle*>(_v)); break;
        case 6: setGraph(*reinterpret_cast< QCPGraph**>(_v)); break;
        case 7: setGraphKey(*reinterpret_cast< double*>(_v)); break;
        case 8: setInterpolating(*reinterpret_cast< bool*>(_v)); break;
        }
        _id -= 9;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 9;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPItemBracket[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       4,   14, // properties
       1,   26, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
      20,   15, 0x4d095103,
      24,   15, 0x4d095103,
      43,   36, 0x06095103,
      63,   50, 0x0009510b,

 // enums: name, flags, count, data
      50, 0x0,    4,   30,

 // enum data: key, value
      69, uint(QCPItemBracket::bsSquare),
      78, uint(QCPItemBracket::bsRound),
      86, uint(QCPItemBracket::bsCurly),
      94, uint(QCPItemBracket::bsCalligraphic),

       0        // eod
};

static const char qt_meta_stringdata_QCPItemBracket[] = {
    "QCPItemBracket\0QPen\0pen\0selectedPen\0"
    "double\0length\0BracketStyle\0style\0"
    "bsSquare\0bsRound\0bsCurly\0bsCalligraphic\0"
};

const QMetaObject QCPItemBracket::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemBracket,
      qt_meta_data_QCPItemBracket, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPItemBracket::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPItemBracket::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPItemBracket::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemBracket))
        return static_cast<void*>(const_cast< QCPItemBracket*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemBracket::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        case 2: *reinterpret_cast< double*>(_v) = length(); break;
        case 3: *reinterpret_cast< BracketStyle*>(_v) = style(); break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: setLength(*reinterpret_cast< double*>(_v)); break;
        case 3: setStyle(*reinterpret_cast< BracketStyle*>(_v)); break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
static const uint qt_meta_data_QCPPolarAxisRadial[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       5,   59, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: signature, parameters, type, tag, flags
      29,   20,   19,   19, 0x05,
      70,   52,   19,   19, 0x05,
     112,  102,   19,   19, 0x05,
     166,  160,   19,   19, 0x05,
     220,  160,   19,   19, 0x05,

 // slots: signature, parameters, type, tag, flags
     280,  275,   19,   19, 0x0a,
     330,  324,   19,   19, 0x0a,
     365,  349,   19,   19, 0x0a,
     435,  421,   19,   19, 0x0a,

 // enums: name, flags, count, data
     489, 0x0,    2,   79,
     504, 0x0,    2,   83,
     514, 0x0,    4,   87,
     529, 0x1,    4,   95,
     545, 0x0,    2,  103,

 // enum data: key, value
     555, uint(QCPPolarAxisRadial::arAbsolute),
     566, uint(QCPPolarAxisRadial::arAngularAxis),
     580, uint(QCPPolarAxisRadial::stLinear),
     589, uint(QCPPolarAxisRadial::stLogarithmic),
     603, uint(QCPPolarAxisRadial::spNone),
     610, uint(QCPPolarAxisRadial::spAxis),
     617, uint(QCPPolarAxisRadial::spTickLabels),
     630, uint(QCPPolarAxisRadial::spAxisLabel),
     603, uint(QCPPolarAxisRadial::spNone),
     610, uint(QCPPolarAxisRadial::spAxis),
     617, uint(QCPPolarAxisRadial::spTickLabels),
     630, uint(QCPPolarAxisRadial::spAxisLabel),
     642, uint(QCPPolarAxisRadial::lmUpright),
     652, uint(QCPPolarAxisRadial::lmRotated),

       0        // eod
};

static const char qt_meta_stringdata_QCPPolarAxisRadial[] = {
    "QCPPolarAxisRadial\0\0newRange\0"
    "rangeChanged(QCPRange)\0newRange,oldRange\0"
    "rangeChanged(QCPRange,QCPRange)\0"
    "scaleType\0scaleTypeChanged(QCPPolarAxisRadial::ScaleType)\0"
    "parts\0selectionChanged(QCPPolarAxisRadial::SelectableParts)\0"
    "selectableChanged(QCPPolarAxisRadial::SelectableParts)\0"
    "type\0setScaleType(QCPPolarAxisRadial::ScaleType)\0"
    "range\0setRange(QCPRange)\0selectableParts\0"
    "setSelectableParts(QCPPolarAxisRadial::SelectableParts)\0"
    "selectedParts\0"
    "setSelectedParts(QCPPolarAxisRadial::SelectableParts)\0"
    "AngleReference\0ScaleType\0SelectablePart\0"
    "SelectableParts\0LabelMode\0arAbsolute\0"
    "arAngularAxis\0stLinear\0stLogarithmic\0"
    "spNone\0spAxis\0spTickLabels\0spAxisLabel\0"
    "lmUpright\0lmRotated\0"
};

const QMetaObject QCPPolarAxisRadial::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPPolarAxisRadial,
      qt_meta_data_QCPPolarAxisRadial, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPPolarAxisRadial::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPPolarAxisRadial::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPPolarAxisRadial::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPPolarAxisRadial))
        return static_cast<void*>(const_cast< QCPPolarAxisRadial*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPPolarAxisRadial::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: rangeChanged((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 1: rangeChanged((*reinterpret_cast< const QCPRange(*)>(_a[1])),(*reinterpret_cast< const QCPRange(*)>(_a[2]))); break;
        case 2: scaleTypeChanged((*reinterpret_cast< QCPPolarAxisRadial::ScaleType(*)>(_a[1]))); break;
        case 3: selectionChanged((*reinterpret_cast< const QCPPolarAxisRadial::SelectableParts(*)>(_a[1]))); break;
        case 4: selectableChanged((*reinterpret_cast< const QCPPolarAxisRadial::SelectableParts(*)>(_a[1]))); break;
        case 5: setScaleType((*reinterpret_cast< QCPPolarAxisRadial::ScaleType(*)>(_a[1]))); break;
        case 6: setRange((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 7: setSelectableParts((*reinterpret_cast< const QCPPolarAxisRadial::SelectableParts(*)>(_a[1]))); break;
        case 8: setSelectedParts((*reinterpret_cast< const QCPPolarAxisRadial::SelectableParts(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void QCPPolarAxisRadial::rangeChanged(const QCPRange & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPPolarAxisRadial::rangeChanged(const QCPRange & _t1, const QCPRange & _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPPolarAxisRadial::scaleTypeChanged(QCPPolarAxisRadial::ScaleType _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void QCPPolarAxisRadial::selectionChanged(const QCPPolarAxisRadial::SelectableParts & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void QCPPolarAxisRadial::selectableChanged(const QCPPolarAxisRadial::SelectableParts & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
static const uint qt_meta_data_QCPPolarAxisAngular[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       3,   49, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: signature, parameters, type, tag, flags
      30,   21,   20,   20, 0x05,
      71,   53,   20,   20, 0x05,
     109,  103,   20,   20, 0x05,
     164,  103,   20,   20, 0x05,

 // slots: signature, parameters, type, tag, flags
     226,  220,   20,   20, 0x0a,
     261,  245,   20,   20, 0x0a,
     332,  318,   20,   20, 0x0a,

 // enums: name, flags, count, data
     387, 0x0,    4,   61,
     402, 0x1,    4,   69,
     418, 0x0,    2,   77,

 // enum data: key, value
     428, uint(QCPPolarAxisAngular::spNone),
     435, uint(QCPPolarAxisAngular::spAxis),
     442, uint(QCPPolarAxisAngular::spTickLabels),
     455, uint(QCPPolarAxisAngular::spAxisLabel),
     428, uint(QCPPolarAxisAngular::spNone),
     435, uint(QCPPolarAxisAngular::spAxis),
     442, uint(QCPPolarAxisAngular::spTickLabels),
     455, uint(QCPPolarAxisAngular::spAxisLabel),
     467, uint(QCPPolarAxisAngular::lmUpright),
     477, uint(QCPPolarAxisAngular::lmRotated),

       0        // eod
};

static const char qt_meta_stringdata_QCPPolarAxisAngular[] = {
    "QCPPolarAxisAngular\0\0newRange\0"
    "rangeChanged(QCPRange)\0newRange,oldRange\0"
    "rangeChanged(QCPRange,QCPRange)\0parts\0"
    "selectionChanged(QCPPolarAxisAngular::SelectableParts)\0"
    "selectableChanged(QCPPolarAxisAngular::SelectableParts)\0"
    "range\0setRange(QCPRange)\0selectableParts\0"
    "setSelectableParts(QCPPolarAxisAngular::SelectableParts)\0"
    "selectedParts\0"
    "setSelectedParts(QCPPolarAxisAngular::SelectableParts)\0"
    "SelectablePart\0SelectableParts\0LabelMode\0"
    "spNone\0spAxis\0spTickLabels\0spAxisLabel\0"
    "lmUpright\0lmRotated\0"
};

const QMetaObject QCPPolarAxisAngular::staticMetaObject = {
    { &QCPLayoutElement::staticMetaObject, qt_meta_stringdata_QCPPolarAxisAngular,
      qt_meta_data_QCPPolarAxisAngular, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPPolarAxisAngular::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPPolarAxisAngular::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPPolarAxisAngular::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPPolarAxisAngular))
        return static_cast<void*>(const_cast< QCPPolarAxisAngular*>(this));
    return QCPLayoutElement::qt_metacast(_clname);
}

int QCPPolarAxisAngular::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutElement::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: rangeChanged((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 1: rangeChanged((*reinterpret_cast< const QCPRange(*)>(_a[1])),(*reinterpret_cast< const QCPRange(*)>(_a[2]))); break;
        case 2: selectionChanged((*reinterpret_cast< const QCPPolarAxisAngular::SelectableParts(*)>(_a[1]))); break;
        case 3: selectableChanged((*reinterpret_cast< const QCPPolarAxisAngular::SelectableParts(*)>(_a[1]))); break;
        case 4: setRange((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 5: setSelectableParts((*reinterpret_cast< const QCPPolarAxisAngular::SelectableParts(*)>(_a[1]))); break;
        case 6: setSelectedParts((*reinterpret_cast< const QCPPolarAxisAngular::SelectableParts(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void QCPPolarAxisAngular::rangeChanged(const QCPRange & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPPolarAxisAngular::rangeChanged(const QCPRange & _t1, const QCPRange & _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPPolarAxisAngular::selectionChanged(const QCPPolarAxisAngular::SelectableParts & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void QCPPolarAxisAngular::selectableChanged(const QCPPolarAxisAngular::SelectableParts & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
static const uint qt_meta_data_QCPPolarGrid[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       2,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
      13, 0x0,    4,   22,
      22, 0x1,    4,   30,

 // enum data: key, value
      32, uint(QCPPolarGrid::gtAngular),
      42, uint(QCPPolarGrid::gtRadial),
      51, uint(QCPPolarGrid::gtAll),
      57, uint(QCPPolarGrid::gtNone),
      32, uint(QCPPolarGrid::gtAngular),
      42, uint(QCPPolarGrid::gtRadial),
      51, uint(QCPPolarGrid::gtAll),
      57, uint(QCPPolarGrid::gtNone),

       0        // eod
};

static const char qt_meta_stringdata_QCPPolarGrid[] = {
    "QCPPolarGrid\0GridType\0GridTypes\0"
    "gtAngular\0gtRadial\0gtAll\0gtNone\0"
};

const QMetaObject QCPPolarGrid::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPPolarGrid,
      qt_meta_data_QCPPolarGrid, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPPolarGrid::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPPolarGrid::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPPolarGrid::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPPolarGrid))
        return static_cast<void*>(const_cast< QCPPolarGrid*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPPolarGrid::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_QCPPolarLegendItem[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_QCPPolarLegendItem[] = {
    "QCPPolarLegendItem\0"
};

const QMetaObject QCPPolarLegendItem::staticMetaObject = {
    { &QCPAbstractLegendItem::staticMetaObject, qt_meta_stringdata_QCPPolarLegendItem,
      qt_meta_data_QCPPolarLegendItem, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPPolarLegendItem::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPPolarLegendItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPPolarLegendItem::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPPolarLegendItem))
        return static_cast<void*>(const_cast< QCPPolarLegendItem*>(this));
    return QCPAbstractLegendItem::qt_metacast(_clname);
}

int QCPPolarLegendItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractLegendItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_QCPPolarGraph[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       1,   39, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: signature, parameters, type, tag, flags
      24,   15,   14,   14, 0x05,
      57,   47,   14,   14, 0x05,
     103,   92,   14,   14, 0x05,

 // slots: signature, parameters, type, tag, flags
     141,   92,   14,   14, 0x0a,
     175,   47,   14,   14, 0x0a,

 // enums: name, flags, count, data
     206, 0x0,    2,   43,

 // enum data: key, value
     216, uint(QCPPolarGraph::lsNone),
     223, uint(QCPPolarGraph::lsLine),

       0        // eod
};

static const char qt_meta_stringdata_QCPPolarGraph[] = {
    "QCPPolarGraph\0\0selected\0selectionChanged(bool)\0"
    "selection\0selectionChanged(QCPDataSelection)\0"
    "selectable\0selectableChanged(QCP::SelectionType)\0"
    "setSelectable(QCP::SelectionType)\0"
    "setSelection(QCPDataSelection)\0LineStyle\0"
    "lsNone\0lsLine\0"
};

const QMetaObject QCPPolarGraph::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPPolarGraph,
      qt_meta_data_QCPPolarGraph, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QCPPolarGraph::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QCPPolarGraph::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QCPPolarGraph::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPPolarGraph))
        return static_cast<void*>(const_cast< QCPPolarGraph*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPPolarGraph::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: selectionChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: selectionChanged((*reinterpret_cast< const QCPDataSelection(*)>(_a[1]))); break;
        case 2: selectableChanged((*reinterpret_cast< QCP::SelectionType(*)>(_a[1]))); break;
        case 3: setSelectable((*reinterpret_cast< QCP::SelectionType(*)>(_a[1]))); break;
        case 4: setSelection((*reinterpret_cast< QCPDataSelection(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void QCPPolarGraph::selectionChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPPolarGraph::selectionChanged(const QCPDataSelection & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPPolarGraph::selectableChanged(QCP::SelectionType _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_END_MOC_NAMESPACE
